-- Pure AI & ML Smart Land Registry MySQL Database Schema
-- Compatible with MySQL 5.7+ / MySQL 8.0+

CREATE DATABASE IF NOT EXISTS land_registry_db;
USE land_registry_db;

-- 1. User Management Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    citizen_id VARCHAR(20) NOT NULL UNIQUE, -- Unique Citizen ID e.g. CTZ-2026-0001
    username VARCHAR(80) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'citizen', -- citizen, registrar, admin
    age INT DEFAULT NULL,
    city VARCHAR(80) DEFAULT NULL,
    state VARCHAR(80) DEFAULT NULL,
    aadhar VARCHAR(20) DEFAULT NULL,
    pan VARCHAR(20) DEFAULT NULL,
    is_verified TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Land Registration Table
CREATE TABLE IF NOT EXISTS lands (
    id INT AUTO_INCREMENT PRIMARY KEY,
    survey_number VARCHAR(50) NOT NULL UNIQUE,
    owner_id INT NOT NULL,
    area FLOAT NOT NULL, -- in square feet
    location VARCHAR(100) NOT NULL,
    latitude FLOAT NOT NULL,
    longitude FLOAT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, verified, flagged, for_sale
    price FLOAT NOT NULL,
    description TEXT,
    pid VARCHAR(50) DEFAULT NULL,
    city VARCHAR(80) DEFAULT NULL,
    state VARCHAR(80) DEFAULT NULL,
    image_path VARCHAR(255) DEFAULT NULL,
    aadhar_path VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Document Verification (OCR) Table
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    land_id INT NOT NULL,
    document_type VARCHAR(50) NOT NULL, -- title_deed, tax_receipt, survey_map
    file_path VARCHAR(255) NOT NULL,
    hash_value VARCHAR(64) NOT NULL, -- SHA-256 file integrity check
    verification_status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, approved, rejected
    verification_notes TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(land_id) REFERENCES lands(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Land Records & Ownership History Table
CREATE TABLE IF NOT EXISTS ownership_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    land_id INT NOT NULL,
    previous_owner_id INT DEFAULT NULL, -- NULL for original land registration
    new_owner_id INT NOT NULL,
    transfer_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    transfer_price FLOAT NOT NULL,
    transfer_ref VARCHAR(64) NOT NULL UNIQUE, -- e.g. REC-20260729-1001
    FOREIGN KEY(land_id) REFERENCES lands(id) ON DELETE CASCADE,
    FOREIGN KEY(previous_owner_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY(new_owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. AI Fraud Detection Records Table
CREATE TABLE IF NOT EXISTS fraud_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    land_id INT NOT NULL,
    risk_score FLOAT NOT NULL DEFAULT 0.0, -- 0.0 to 1.0 (0% - 100%)
    fraud_flags TEXT, -- JSON array of anomaly flags
    status VARCHAR(20) NOT NULL DEFAULT 'investigating', -- investigating, resolved_clear, confirmed_fraud
    ai_feedback TEXT,
    reported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(land_id) REFERENCES lands(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Property Price Prediction Logs Table
CREATE TABLE IF NOT EXISTS price_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    land_id INT NOT NULL,
    predicted_price FLOAT NOT NULL,
    low_estimate FLOAT NOT NULL,
    high_estimate FLOAT NOT NULL,
    confidence_score FLOAT NOT NULL,
    prediction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(land_id) REFERENCES lands(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Land Transfer Request & Approval Table
CREATE TABLE IF NOT EXISTS land_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    land_id INT NOT NULL,
    seller_id INT DEFAULT NULL,
    buyer_id INT NOT NULL,
    seller_citizen_id VARCHAR(20) DEFAULT NULL,
    buyer_citizen_id VARCHAR(20) DEFAULT NULL,
    bid_price FLOAT DEFAULT 0.0,
    transfer_reason VARCHAR(50) DEFAULT 'Sale',
    transfer_doc_path VARCHAR(255) DEFAULT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, approved, rejected
    rejection_reason TEXT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(land_id) REFERENCES lands(id) ON DELETE CASCADE,
    FOREIGN KEY(seller_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY(buyer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
