import os
import sys

# Redirect execution to parent generate_large_dataset.py
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

from generate_large_dataset import generate_dataset

if __name__ == '__main__':
    generate_dataset()
