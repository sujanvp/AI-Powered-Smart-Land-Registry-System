import os
import sys
import unittest

from app import create_app
from models import db
from models.user import User
from models.land import Land
from models.request import LandRequest
from models.ownership import OwnershipHistory
from models.notification import Notification

class TestLandTransferWorkflow(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['WTF_CSRF_ENABLED'] = False
        self.client = self.app.test_client()
        self.ctx = self.app.app_context()
        self.ctx.push()

    def tearDown(self):
        self.ctx.pop()

    def login_as(self, user, password='password'):
        user.set_password(password)
        db.session.commit()
        self.client.get('/logout', follow_redirects=True)
        return self.client.post('/login', data={'username': user.username, 'password': password}, follow_redirects=True)

    def test_full_transfer_workflow(self):
        # 1. Setup Test Users
        seller = User.query.filter_by(role='citizen').first()
        buyer = User.query.filter(User.role == 'citizen', User.id != seller.id).first()
        officer = User.query.filter(User.role == 'registrar').first()
        if not officer:
            officer = User(username="registrar_officer", email="registrar@test.com", role="registrar", is_verified=True, status="approved")
            officer.set_password("password")
            db.session.add(officer)
            db.session.commit()

        seller.set_password('password')
        buyer.set_password('password')
        officer.set_password('password')
        officer.is_verified = True
        officer.status = 'approved'
        db.session.commit()

        # 2. Setup Test Land owned by Seller
        test_land = Land.query.filter_by(owner_id=seller.id).first()
        if not test_land:
            test_land = Land(
                survey_number=f"SURVEY-WF-{os.urandom(3).hex().upper()}",
                owner_id=seller.id,
                area=2400.0,
                location="Test Location, Hyderabad",
                latitude=17.3850,
                longitude=78.4867,
                status="verified",
                price=4500000.0,
                description="Test Land Workflow",
                pid="PID-TEST-9999",
                city="Hyderabad",
                state="Telangana"
            )
            db.session.add(test_land)
            db.session.commit()

        # 3. Citizen Submits Land Transfer Request
        transfer_req = LandRequest(
            land_id=test_land.id,
            seller_id=seller.id,
            buyer_id=buyer.id,
            seller_citizen_id=seller.citizen_id,
            buyer_citizen_id=buyer.citizen_id,
            bid_price=4500000.0,
            transfer_reason="Sale",
            status="pending"
        )
        test_land.status = "pending"
        db.session.add(transfer_req)
        db.session.commit()

        # 4. Verify Pending Request CANNOT generate certificate
        self.login_as(seller)
        res_pending_cert = self.client.get(f"/certificate/transfer/{transfer_req.id}", follow_redirects=True)
        self.assertIn(b"Certificate unavailable", res_pending_cert.data)

        # 5. Revenue Officer approves the transfer request
        self.login_as(officer)
        approve_res = self.client.post(f"/request/{transfer_req.id}/approve", follow_redirects=True)
        self.assertEqual(approve_res.status_code, 200)

        # 6. Verify Database updates (Online approval = Transfer Approval ONLY; ownership is NOT transferred online)
        db.session.expire_all()
        updated_land = db.session.get(Land, test_land.id)
        updated_req = db.session.get(LandRequest, transfer_req.id)
        self.assertEqual(updated_land.owner_id, seller.id)
        self.assertEqual(updated_req.status, 'approved')

        # 7. Verify Notification sent ONLY to Submitting Citizen
        seller_notifs = Notification.query.filter_by(
            user_id=seller.id,
            related_request_id=transfer_req.id,
            notification_type="land_transfer_approved"
        ).all()
        self.assertEqual(len(seller_notifs), 1)

        buyer_notifs = Notification.query.filter_by(
            user_id=buyer.id,
            related_request_id=transfer_req.id,
            notification_type="land_transfer_approved"
        ).all()
        self.assertEqual(len(buyer_notifs), 0)

        # 8. Citizen clicks notification / opens Transfer Approval Certificate
        self.login_as(seller)
        cert_page_res = self.client.get(f"/certificate/transfer/{transfer_req.id}")
        self.assertEqual(cert_page_res.status_code, 200)
        self.assertIn(b"TRANSFER APPROVAL CERTIFICATE", cert_page_res.data)
        self.assertIn(b"For Offline Registration & Documentation", cert_page_res.data)
        self.assertIn(b"APPROVED FOR OFFLINE REGISTRATION", cert_page_res.data)
        self.assertIn(b"OFFLINE REGISTRATION / DOCUMENTATION", cert_page_res.data)
        self.assertIn(b"This certificate confirms only the online approval of the proposed land transfer. It does not constitute final legal registration or transfer of title.", cert_page_res.data)


        # 9. Download Transfer Approval Certificate PDF
        pdf_res = self.client.get(f"/certificate/transfer/{transfer_req.id}/download")
        self.assertEqual(pdf_res.status_code, 200)
        self.assertEqual(pdf_res.mimetype, 'application/pdf')
        self.assertTrue(len(pdf_res.data) > 1000)

        # 10. Verify Final Certificate CANNOT be accessed before offline verification
        self.login_as(buyer)
        final_cert_premature = self.client.get(f"/certificate/final/{transfer_req.id}", follow_redirects=True)
        self.assertIn(b"Final Transfer Certificate is unavailable", final_cert_premature.data)

        # 11. Revenue Officer opens Land Transfer Requests & clicks EDIT on request with status APPROVED FOR OFFLINE REGISTRATION
        self.login_as(officer)
        requests_page_res = self.client.get("/transfer-requests")
        self.assertEqual(requests_page_res.status_code, 200)
        self.assertIn(b"APPROVED FOR OFFLINE REGISTRATION", requests_page_res.data)

        # Click EDIT on exact transfer request (GET /request/<id>/edit)
        edit_page_res = self.client.get(f"/request/{transfer_req.id}/edit")
        self.assertEqual(edit_page_res.status_code, 200)
        self.assertIn(b"EDIT TRANSFER REQUEST", edit_page_res.data)
        self.assertIn(test_land.survey_number.encode(), edit_page_res.data)

        # 12. Revenue Officer saves draft via SAVE DRAFT button from EDIT page
        import io
        draft_save_data = {
            'submit_action': 'save_draft',
            'seller_id_verified': '1',
            'seller_sig_verified': '1',
            'buyer_id_verified': '1',
            'buyer_sig_verified': '1',
            'registration_office': 'Sub-Registrar Office, Hyderabad Zone',
            'registration_date': '2026-09-10',
            'officer_name': officer.username,
            'officer_id': 'RO-HYD-2026',
            'verification_remarks': 'Draft saved remarks: seller and buyer physical signatures collected.',
            'seller_signature_file': (io.BytesIO(b'mock_seller_signature_content'), 'seller_signature.png'),
            'buyer_signature_file': (io.BytesIO(b'mock_buyer_signature_content'), 'buyer_signature.png')
        }
        save_res = self.client.post(f"/request/{transfer_req.id}/edit", data=draft_save_data, content_type='multipart/form-data', follow_redirects=True)
        self.assertEqual(save_res.status_code, 200)
        self.assertIn(b"Draft saved successfully", save_res.data)

        # Reopen EDIT page and confirm saved files & fields exist, status remains 'approved'
        edit_reopen_res = self.client.get(f"/request/{transfer_req.id}/edit")
        self.assertEqual(edit_reopen_res.status_code, 200)
        self.assertIn(b"View Uploaded Seller Signature", edit_reopen_res.data)
        self.assertIn(b"View Uploaded Buyer Signature", edit_reopen_res.data)
        self.assertIn(b"Draft saved remarks", edit_reopen_res.data)

        db.session.expire_all()
        intermediate_req = db.session.get(LandRequest, transfer_req.id)
        self.assertEqual(intermediate_req.status, 'approved')

        # 13. Revenue Officer submits SUBMIT & COMPLETE FINAL REGISTRATION from EDIT page
        final_post_data = {
            'submit_action': 'complete',
            'seller_id_verified': '1',
            'seller_sig_verified': '1',
            'buyer_id_verified': '1',
            'buyer_sig_verified': '1',
            'doc_orig_verified': '1',
            'doc_supp_verified': '1',
            'registration_office': 'Sub-Registrar Office, Hyderabad Zone',
            'registration_date': '2026-09-10',
            'officer_name': officer.username,
            'officer_id': 'RO-HYD-2026',
            'verification_remarks': 'Verified physical identity, biometric seller/buyer signatures, and original title deeds.',
            'offline_doc_file': (io.BytesIO(b'mock_offline_document_content'), 'offline_document.pdf')
        }
        complete_res = self.client.post(f"/request/{transfer_req.id}/edit", data=final_post_data, content_type='multipart/form-data', follow_redirects=True)
        self.assertEqual(complete_res.status_code, 200)
        self.assertIn(b"FINAL TRANSFER CERTIFICATE", complete_res.data)

        # 13. Verify Database updates after Final Approval:
        db.session.expire_all()
        final_land = db.session.get(Land, test_land.id)
        final_req = db.session.get(LandRequest, transfer_req.id)

        # Ownership updated to Buyer
        self.assertEqual(final_land.owner_id, buyer.id)
        self.assertEqual(final_req.status, 'completed')

        # Ownership History updated
        latest_history = OwnershipHistory.query.filter_by(land_id=test_land.id).order_by(OwnershipHistory.transfer_date.desc()).first()
        self.assertIsNotNone(latest_history)
        self.assertEqual(latest_history.previous_owner_id, seller.id)
        self.assertEqual(latest_history.new_owner_id, buyer.id)

        # 14. Verify Final Transfer Notification sent to Citizen
        final_notifs = Notification.query.filter_by(
            user_id=buyer.id,
            related_request_id=transfer_req.id,
            notification_type="final_transfer_approved"
        ).all()
        self.assertEqual(len(final_notifs), 1)
        self.assertIn("Your land transfer has been successfully completed after offline verification", final_notifs[0].message)

        # 15. Citizen views and downloads Final Transfer Certificate
        self.login_as(buyer)
        final_cert_view = self.client.get(f"/certificate/final/{transfer_req.id}")
        self.assertEqual(final_cert_view.status_code, 200)
        self.assertIn(b"FINAL TRANSFER CERTIFICATE", final_cert_view.data)
        self.assertIn(b"FINAL REGISTERED / TRANSFER COMPLETED", final_cert_view.data)

        final_pdf_res = self.client.get(f"/certificate/final/{transfer_req.id}/download")
        self.assertEqual(final_pdf_res.status_code, 200)
        self.assertEqual(final_pdf_res.mimetype, 'application/pdf')
        self.assertTrue(len(final_pdf_res.data) > 1000)

        # 16. Verify earlier Transfer Approval Certificate remains available
        approval_cert_still_valid = self.client.get(f"/certificate/transfer/{transfer_req.id}")
        self.assertEqual(approval_cert_still_valid.status_code, 200)
        self.assertIn(b"TRANSFER APPROVAL CERTIFICATE", approval_cert_still_valid.data)

        # 17. Verify Top Navigation Survey Number Search for Registrar & Admin
        # Test Registrar Search
        self.login_as(officer)
        search_res_officer = self.client.get(f"/records?q={test_land.survey_number}")
        self.assertEqual(search_res_officer.status_code, 200)
        self.assertIn(b"SURVEY NUMBER:", search_res_officer.data)
        self.assertNotIn(b"GLOBAL SURVEY NUMBER LOOKUP RESULT", search_res_officer.data)
        self.assertIn(b"Land Registration Details", search_res_officer.data)
        self.assertIn(b"Current Ownership Details", search_res_officer.data)
        self.assertIn(b"Land Transfer Requests", search_res_officer.data)
        self.assertIn(b"Pending Transfer Requests", search_res_officer.data)
        self.assertIn(b"Complete Ownership History", search_res_officer.data)
        self.assertIn(b"Complete Transfer History", search_res_officer.data)
        self.assertIn(b"Approval / Final Registration Status", search_res_officer.data)
        self.assertIn(b"Documents / Certificates", search_res_officer.data)

        # Test Admin Search
        admin_user = User.query.filter_by(role='admin').first()
        if not admin_user:
            admin_user = User(username="admin_test", email="admin@test.com", role="admin", is_verified=True, status="approved")
            admin_user.set_password("password")
            db.session.add(admin_user)
            db.session.commit()
        else:
            admin_user.set_password("password")
            db.session.commit()

        self.login_as(admin_user)
        search_res_admin = self.client.get(f"/records?q={test_land.survey_number}")
        self.assertEqual(search_res_admin.status_code, 200)
        self.assertIn(b"SURVEY NUMBER:", search_res_admin.data)
        self.assertNotIn(b"GLOBAL SURVEY NUMBER LOOKUP RESULT", search_res_admin.data)
        self.assertIn(b"Land Registration Details", search_res_admin.data)

        # Test Non-existent Survey Number Search
        search_res_empty = self.client.get("/records?q=SY-NONEXISTENT-99999")
        self.assertEqual(search_res_empty.status_code, 200)
        self.assertIn(b"No records found for this Survey Number.", search_res_empty.data)

if __name__ == '__main__':
    unittest.main()

