import os
from flask import Flask, redirect, url_for, render_template
from flask_login import LoginManager
from models import db
from models.user import User
from config import Config

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Initialize Database
    db.init_app(app)
    
    # Configure SQLite Performance Pragmas
    with app.app_context():
        try:
            from sqlalchemy import event
            from sqlalchemy.engine import Engine

            @event.listens_for(Engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                if app.config['SQLALCHEMY_DATABASE_URI'].startswith('sqlite'):
                    cursor = dbapi_connection.cursor()
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA cache_size=-64000")
                    cursor.execute("PRAGMA temp_store=MEMORY")
                    cursor.close()
        except Exception:
            pass

    
    # Initialize Login Manager
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
        
    # Ensure necessary folders exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['ML_MODEL_FOLDER'], exist_ok=True)
    os.makedirs(os.path.join(app.config['BASE_DIR'], 'dataset'), exist_ok=True)
    
    # Register blueprints (imported inside function to prevent circular imports)
    from routes.auth import auth_bp
    from routes.land import land_bp
    from routes.document import doc_bp
    from routes.ownership import ownership_bp
    from routes.fraud import fraud_bp
    from routes.prediction import pred_bp
    from routes.admin import admin_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(land_bp)
    app.register_blueprint(doc_bp)
    app.register_blueprint(ownership_bp)
    app.register_blueprint(fraud_bp)
    app.register_blueprint(pred_bp)
    app.register_blueprint(admin_bp)
    
    # Global utility filter for formatting numbers as Indian Rupees (INR / ₹)
    @app.template_filter('currency')
    def currency_filter(value):
        try:
            val = float(value)
            parts = f"{val:.0f}".split('.')
            integer_part = parts[0]
            if len(integer_part) > 3:
                last_three = integer_part[-3:]
                remaining = integer_part[:-3]
                out = ""
                while len(remaining) > 2:
                    out = "," + remaining[-2:] + out
                    remaining = remaining[:-2]
                if remaining:
                    out = remaining + out
                formatted_int = out + "," + last_three
            else:
                formatted_int = integer_part
            return f"₹{formatted_int}"
        except (ValueError, TypeError):
            return f"₹{value}"

            
    # Default Route redirects to landing index
    @app.route('/')
    def index():
        return render_template('index.html')
        
    # Custom Error Handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('error.html', error_code=404, error_message="Page Not Found", error_description="The page you are looking for does not exist, has been moved, or is temporarily unavailable."), 404
        
    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('error.html', error_code=500, error_message="Internal Server Error", error_description="An unexpected error occurred. The AI system is auditing server logs."), 500
        
    @app.context_processor
    def inject_notifications():
        from flask_login import current_user
        if current_user.is_authenticated:
            try:
                from models.notification import Notification
                notifs = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(15).all()
                unread_cnt = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
                return dict(user_notifications=notifs, unread_notification_count=unread_cnt)
            except Exception:
                return dict(user_notifications=[], unread_notification_count=0)
        return dict(user_notifications=[], unread_notification_count=0)

    # Create DB tables
    with app.app_context():
        db.create_all()
        try:
            from sqlalchemy import inspect, text
            inspector = inspect(db.engine)
            
            land_cols = [c['name'] for c in inspector.get_columns('lands')]
            with db.engine.connect() as conn:
                if 'rejection_reason' not in land_cols:
                    conn.execute(text("ALTER TABLE lands ADD COLUMN rejection_reason TEXT;"))
                if 'rejected_by' not in land_cols:
                    conn.execute(text("ALTER TABLE lands ADD COLUMN rejected_by VARCHAR(80);"))
                if 'rejected_at' not in land_cols:
                    conn.execute(text("ALTER TABLE lands ADD COLUMN rejected_at DATETIME;"))
                conn.commit()
                
            req_cols = [c['name'] for c in inspector.get_columns('land_requests')]
            with db.engine.connect() as conn:
                if 'rejected_by' not in req_cols:
                    conn.execute(text("ALTER TABLE land_requests ADD COLUMN rejected_by VARCHAR(80);"))
                if 'rejected_at' not in req_cols:
                    conn.execute(text("ALTER TABLE land_requests ADD COLUMN rejected_at DATETIME;"))
                conn.commit()

            user_cols = [c['name'] for c in inspector.get_columns('users')]
            with db.engine.connect() as conn:
                if 'rejected_by' not in user_cols:
                    conn.execute(text("ALTER TABLE users ADD COLUMN rejected_by VARCHAR(80);"))
                if 'rejected_at' not in user_cols:
                    conn.execute(text("ALTER TABLE users ADD COLUMN rejected_at DATETIME;"))
                conn.commit()
        except Exception:
            pass
            
    return app
