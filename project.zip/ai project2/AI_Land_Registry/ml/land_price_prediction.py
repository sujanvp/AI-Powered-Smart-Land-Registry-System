import os
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score

# Get absolute path relative to this file
ML_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_MODEL_PATH = os.path.join(ML_DIR, 'models', 'price_model.pkl')

def train_model(dataset_path, model_path=DEFAULT_MODEL_PATH):
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset not found at {dataset_path}")
        
    df = pd.read_csv(dataset_path)
    
    # Filter for non-fraudulent transactions to train a reliable 'fair' valuation model
    df_clean = df[df['is_fraud'] == 0]
    
    X = df_clean[['location', 'area', 'latitude', 'longitude']]
    y = df_clean['transaction_price']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Set up preprocessing pipeline
    categorical_features = ['location']
    numeric_features = ['area', 'latitude', 'longitude']
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numeric_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ])
        
    # Append regressor to pipeline
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))
    ])
    
    # Train
    pipeline.fit(X_train, y_train)
    
    # Evaluate
    y_pred = pipeline.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    print(f"Price Prediction Model trained with R2 score: {r2:.4f}")
    
    # Save the pipeline and the testing performance metric
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    with open(model_path, 'wb') as f:
        pickle.dump({'pipeline': pipeline, 'r2': r2}, f)
    print(f"Model saved to {model_path}")
    return r2

def predict_land_price(location, area, lat, lon, model_path=DEFAULT_MODEL_PATH):
    try:
        with open(model_path, 'rb') as f:
            data = pickle.load(f)
        pipeline = data['pipeline']
        r2 = data['r2']
    except Exception as e:
        print(f"Error loading price prediction model: {e}. Returning fallback estimates.")
        # Fallback heuristic if model isn't trained yet
        rates = {'Downtown': 550, 'Uptown': 380, 'Suburbs': 220, 'Industrial': 160, 'Rural': 60}
        rate = rates.get(location, 100)
        predicted = float(area * rate)
        return predicted, predicted * 0.9, predicted * 1.1, 0.70
        
    # Create input DataFrame
    input_data = pd.DataFrame([{
        'location': location,
        'area': float(area),
        'latitude': float(lat),
        'longitude': float(lon)
    }])
    
    predicted = float(pipeline.predict(input_data)[0])
    
    # Estimate confidence bounds (+/- 10% base bounds modified by model quality)
    bound_pct = max(0.05, 0.15 - (r2 * 0.1))
    low_est = predicted * (1 - bound_pct)
    high_est = predicted * (1 + bound_pct)
    
    return predicted, low_est, high_est, r2

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ds_path = os.path.join(base_dir, 'dataset', 'land_transactions.csv')
    train_model(ds_path)
