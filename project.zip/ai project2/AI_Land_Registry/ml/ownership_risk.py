import datetime

def calculate_ownership_risk(land):
    """
    Evaluates the risk associated with a land listing.
    Input is a Land model instance (or an object with similar attributes).
    Returns:
    - risk_score (float 0.0 - 1.0)
    - risk_level (str: 'Low', 'Medium', 'High')
    - risk_factors (list of str)
    """
    risk_score = 0.0
    risk_factors = []
    
    # 1. Document verification status check
    total_docs = len(land.documents)
    approved_docs = sum(1 for d in land.documents if d.verification_status == 'approved')
    rejected_docs = sum(1 for d in land.documents if d.verification_status == 'rejected')
    
    if total_docs == 0:
        risk_score += 0.35
        risk_factors.append("No supporting documents uploaded")
    elif approved_docs == 0:
        risk_score += 0.25
        risk_factors.append("No verified documents on record")
        
    if rejected_docs > 0:
        risk_score += 0.40
        risk_factors.append(f"{rejected_docs} document(s) failed verification")
        
    # 2. Transfer frequency check
    transfers = land.ownership_history
    num_transfers = len(transfers)
    
    if num_transfers > 0:
        # Sort by transfer date descending
        sorted_transfers = sorted(transfers, key=lambda t: t.transfer_date, reverse=True)
        most_recent = sorted_transfers[0].transfer_date
        
        # Calculate time delta in days
        now = datetime.datetime.utcnow()
        days_since_transfer = (now - most_recent).days
        
        if days_since_transfer < 30:
            risk_score += 0.30
            risk_factors.append(f"Highly rapid transaction: Title transferred {days_since_transfer} days ago")
        elif days_since_transfer < 180:
            risk_score += 0.15
            risk_factors.append(f"Recent transaction: Title transferred within past 6 months")
            
        # Count transfers in last 365 days
        recent_transfers_count = sum(1 for t in transfers if (now - t.transfer_date).days <= 365)
        if recent_transfers_count >= 3:
            risk_score += 0.25
            risk_factors.append(f"High flipping rate: {recent_transfers_count} transfers in the last 12 months")
    else:
        # No transfers = original registry
        pass
        
    # 3. Registry Status Check
    if land.status == 'flagged':
        risk_score += 0.50
        risk_factors.append("Registry status is currently flagged")
    elif land.status == 'pending':
        risk_score += 0.15
        risk_factors.append("Land details awaiting formal registry approval")
        
    # Bound the score between 0.0 and 1.0
    risk_score = min(1.0, max(0.0, risk_score))
    
    # Risk Level mapping
    if risk_score <= 0.25:
        risk_level = "Low"
    elif risk_score <= 0.60:
        risk_level = "Medium"
    else:
        risk_level = "High"
        
    return risk_score, risk_level, risk_factors
