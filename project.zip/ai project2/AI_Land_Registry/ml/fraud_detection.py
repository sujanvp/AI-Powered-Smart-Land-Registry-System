import os
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Get absolute path relative to this file
ML_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_MODEL_PATH = os.path.join(ML_DIR, 'models', 'fraud_model.pkl')

def train_model(dataset_path, model_path=DEFAULT_MODEL_PATH):
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset not found at {dataset_path}")
        
    df = pd.read_csv(dataset_path)
    
    # We train the classifier using transaction variables:
    # 1. price_variance (ratio of transaction price to fair market price)
    # 2. days_since_last_transfer
    # 3. num_transfers_last_year
    # 4. doc_discrepancy (from document OCR matching)
    
    features = ['price_variance', 'days_since_last_transfer', 'num_transfers_last_year', 'doc_discrepancy']
    X = df[features]
    y = df['is_fraud']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Random Forest Classifier
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_train, y_train)
    
    # Evaluate
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Fraud Detection Model trained with accuracy: {acc:.4f}")
    
    # Save model
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    with open(model_path, 'wb') as f:
        pickle.dump({'model': clf, 'accuracy': acc}, f)
    print(f"Fraud model saved to {model_path}")
    return acc

def detect_fraud(price_variance, days_since_last_transfer, num_transfers_last_year, doc_discrepancy, model_path=DEFAULT_MODEL_PATH):
    # Determine flags based on heuristics
    flags = []
    
    if price_variance < 0.6 or price_variance > 1.8:
        flags.append('Price Anomaly')
    if days_since_last_transfer < 45:
        flags.append('Rapid Ownership Change')
    if num_transfers_last_year >= 3:
        flags.append('High Frequency Transfers')
    if doc_discrepancy > 0:
        flags.append('Document Verification Mismatch')
        
    # Load ML model for probability estimation
    try:
        with open(model_path, 'rb') as f:
            data = pickle.load(f)
        clf = data['model']
    except Exception as e:
        print(f"Error loading fraud detection model: {e}. Using fallback heuristic.")
        # Fallback scoring
        score = 0.0
        if 'Price Anomaly' in flags:
            score += 0.4
        if 'Rapid Ownership Change' in flags:
            score += 0.3
        if 'High Frequency Transfers' in flags:
            score += 0.2
        if 'Document Verification Mismatch' in flags:
            score += 0.5
        score = min(0.99, score)
        return float(score), flags
        
    input_data = pd.DataFrame([{
        'price_variance': float(price_variance),
        'days_since_last_transfer': float(days_since_last_transfer),
        'num_transfers_last_year': float(num_transfers_last_year),
        'doc_discrepancy': int(doc_discrepancy)
    }])
    
    # Get fraud probability (class 1)
    prob = float(clf.predict_proba(input_data)[0][1])
    
    # Ensure flags are raised if ML probability is high but heuristics didn't catch specific details
    if prob > 0.5 and not flags:
        flags.append('AI Flagged Risk Pattern')
        
    return prob, flags

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ds_path = os.path.join(base_dir, 'dataset', 'land_transactions.csv')
    train_model(ds_path)
