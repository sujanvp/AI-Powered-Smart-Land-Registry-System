from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from models import db
from models.ownership import OwnershipHistory
from models.land import Land

ownership_bp = Blueprint('ownership', __name__)

@ownership_bp.route('/ledger')
@ownership_bp.route('/ownership/records')
@login_required
def public_ledger():
    # Redirect to Module 7: Land Records & Ownership History
    return redirect(url_for('land.records'))

@ownership_bp.route('/ledger/verify/<string:tx_hash>')
@ownership_bp.route('/ownership/record/<string:ref_id>')
@login_required
def verify_transaction(tx_hash=None, ref_id=None):
    search_ref = tx_hash or ref_id
    transfer = OwnershipHistory.query.filter_by(transfer_ref=search_ref).first()
    if not transfer and search_ref:
        # Fallback search by ID or string match
        transfer = OwnershipHistory.query.filter(OwnershipHistory.transfer_ref.like(f"%{search_ref}%")).first_or_404()
    elif not transfer:
        return redirect(url_for('land.records'))
        
    return render_template('records.html', records=[{
        'info': transfer.land,
        'history': OwnershipHistory.query.filter_by(land_id=transfer.land_id).order_by(OwnershipHistory.transfer_date.desc()).all()
    }], search_query=search_ref)
