from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
import os
from models import db
from models.user import User

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        return redirect(url_for('land.dashboard'))
        
    if request.method == 'POST':
        role = request.form.get('role', 'citizen')
        
        if role == 'registrar':
            full_name = request.form.get('full_name')
            official_email = request.form.get('official_email') or request.form.get('email')
            mobile_number = request.form.get('mobile_number')
            officer_id = request.form.get('officer_id')
            department = request.form.get('department', 'Revenue & Land Records')
            designation = request.form.get('designation')
            district = request.form.get('district')
            taluk = request.form.get('taluk')
            office_name = request.form.get('office_name')
            office_address = request.form.get('office_address')
            date_of_joining = request.form.get('date_of_joining')
            password = request.form.get('password')
            confirm_password = request.form.get('confirm_password')
            declaration = request.form.get('declaration')

            # Validation Checks
            if password and confirm_password and password != confirm_password:
                flash('Password and Confirm Password do not match.', 'error')
                return redirect(url_for('auth.register'))

            username = officer_id or (full_name.replace(' ', '_').lower() if full_name else None)
            
            # Check if officer ID or email already exists
            user_exists = User.query.filter((User.username == username) | (User.email == official_email) | (User.citizen_id == officer_id)).first()
            if user_exists:
                flash('An account with this Employee / Officer ID or Official Email already exists in the system.', 'error')
                return redirect(url_for('auth.register'))
                
            # Process File Upload if provided
            file = request.files.get('official_id_doc')
            if file and file.filename:
                filename = secure_filename(file.filename)
                upload_dir = os.path.join(current_app.static_folder, 'uploads', 'officer_docs')
                os.makedirs(upload_dir, exist_ok=True)
                file.save(os.path.join(upload_dir, f"{username}_{filename}"))

            new_user = User(
                username=username,
                email=official_email,
                role='registrar',
                city=district,
                state='Maharashtra',
                aadhar=mobile_number,
                is_verified=False, # Status: Pending Verification
                status='pending',
                citizen_id=officer_id if officer_id else None
            )
            new_user.set_password(password)
            
            db.session.add(new_user)
            db.session.commit()
            
            flash("Revenue Officer registration submitted for verification! Your account status is 'Pending Verification'. Please wait for Administrator approval before logging in.", "success")
            return redirect(url_for('auth.login'))
        else:
            username = request.form.get('username')
            email = request.form.get('email')
            password = request.form.get('password')
            
            age_str = request.form.get('age')
            age = int(age_str) if age_str and age_str.isdigit() else None
            city = request.form.get('city')
            state = request.form.get('state')
            aadhar = request.form.get('aadhar')
            pan = request.form.get('pan')
            
            # Check if user exists
            user_exists = User.query.filter((User.username == username) | (User.email == email)).first()
            if user_exists:
                flash('Username or Email already exists in the system.', 'error')
                return redirect(url_for('auth.register'))
                
            new_user = User(
                username=username,
                email=email,
                role=role,
                age=age,
                city=city,
                state=state,
                aadhar=aadhar,
                pan=pan,
                is_verified=True
            )
            new_user.set_password(password)
            
            db.session.add(new_user)
            db.session.commit()
            
            flash(f'Account registered successfully! Your unique Citizen ID is: {new_user.citizen_id}. Please log in.', 'success')
            return redirect(url_for('auth.login'))
        
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        return redirect(url_for('land.dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter((User.username == username) | (User.email == username) | (User.citizen_id == username)).first()
        if user and user.check_password(password):
            # SECURITY BEHAVIOR: Check if Revenue Officer account is pending Admin approval
            if user.role == 'registrar' and (user.status == 'pending' or not user.status) and not user.is_verified:
                flash('Your Revenue Officer account status is Pending Verification. Please wait for Administrator approval before logging in.', 'warning')
                return redirect(url_for('auth.login'))
                
            login_user(user)
            flash(f'Welcome back, {user.username}!', 'success')
            if user.role == 'admin':
                return redirect(url_for('admin.dashboard'))
            else:
                return redirect(url_for('land.dashboard'))
            
        flash('Invalid username or password.', 'error')
        return redirect(url_for('auth.login'))
        
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully from Smart Land Registry system.', 'info')
    return redirect(url_for('index'))
