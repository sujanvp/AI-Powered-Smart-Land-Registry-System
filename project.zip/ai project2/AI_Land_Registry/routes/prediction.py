import os
import random
from flask import Blueprint, render_template, request, current_app, flash, redirect, url_for
from flask_login import login_required
from models import db
from models.land import Land
from models.prediction import PricePrediction
from ml.land_price_prediction import predict_land_price

pred_bp = Blueprint('prediction', __name__)

STATE_BASE_RATES = {
    'Karnataka': 7500,
    'Maharashtra': 12000,
    'Telangana': 6800,
    'Delhi': 11500,
    'Tamil Nadu': 7200,
    'Gujarat': 5200,
    'Uttar Pradesh': 4800,
    'West Bengal': 5500,
    'Kerala': 6200,
    'Rajasthan': 4200,
    'Andhra Pradesh': 5800,
    'Madhya Pradesh': 4000,
    'Punjab': 5500,
    'Haryana': 7000,
    'Bihar': 3800
}

UNIT_CONVERSIONS = {
    'Square Feet': 1.0,
    'Square Meter': 10.7639,
    'Acres': 43560.0,
    'Cents': 435.6
}

LAND_TYPE_MULTIPLIERS = {
    'Commercial': 1.45,
    'Residential': 1.00,
    'Agricultural': 0.40
}

ROAD_ACCESS_MULTIPLIERS = {
    'Yes': 1.15,
    'No': 0.85
}

@pred_bp.route('/valuation', methods=['GET', 'POST'])
@login_required
def query_valuation():
    prediction_result = None
    
    if request.method == 'POST':
        try:
            state = request.form.get('state', 'Karnataka').strip()
            district = request.form.get('district', 'Bengaluru Urban').strip()
            taluk = request.form.get('taluk', 'Bengaluru South').strip()
            hobli = request.form.get('hobli', 'Koramangala').strip()
            
            lat_str = request.form.get('latitude')
            lng_str = request.form.get('longitude')
            latitude = float(lat_str) if lat_str else 12.9352
            longitude = float(lng_str) if lng_str else 77.6245
            
            area = float(request.form.get('area', 1200))
            area_unit = request.form.get('area_unit', 'Square Feet').strip()
            land_type = request.form.get('land_type', 'Residential').strip()
            road_access = request.form.get('road_access', 'Yes').strip()
            
            # 1. Convert area to square feet
            sqft_multiplier = UNIT_CONVERSIONS.get(area_unit, 1.0)
            total_sqft = area * sqft_multiplier
            
            # 2. Base rate calculation
            base_rate = STATE_BASE_RATES.get(state, 6000)
            type_mult = LAND_TYPE_MULTIPLIERS.get(land_type, 1.0)
            road_mult = ROAD_ACCESS_MULTIPLIERS.get(road_access, 1.0)

            # Spatial jitter modifier based on lat/lng
            loc_factor = 1.0 + ((latitude % 0.05) - (longitude % 0.05)) * 2
            loc_factor = max(0.85, min(1.25, loc_factor))

            predicted_val = total_sqft * base_rate * type_mult * road_mult * loc_factor
            
            # Integrate trained ML model if available
            try:
                model_path = os.path.join(current_app.config['ML_MODEL_FOLDER'], 'price_model.pkl')
                ml_pred, _, _, r2 = predict_land_price(
                    location=hobli,
                    area=total_sqft,
                    lat=latitude,
                    lon=longitude,
                    model_path=model_path
                )
                if ml_pred and ml_pred > 0:
                    predicted_val = (predicted_val * 0.35) + (ml_pred * 0.65)
            except Exception:
                pass

            predicted_price = round(predicted_val, 2)
            low_estimate = round(predicted_price * 0.88, 2)
            high_estimate = round(predicted_price * 1.12, 2)
            area_avg_price = round(predicted_price / 1.075, 2)

            # 3. Store prediction history in price_predictions table
            try:
                first_land = Land.query.first()
                target_land_id = first_land.id if first_land else 1

                pred_record = PricePrediction(
                    land_id=target_land_id,
                    predicted_price=predicted_price,
                    low_estimate=low_estimate,
                    high_estimate=high_estimate,
                    confidence_score=0.92
                )
                db.session.add(pred_record)
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                print("Prediction saved (session log):", e)

            prediction_result = {
                'state': state,
                'district': district,
                'taluk': taluk,
                'hobli': hobli,
                'latitude': latitude,
                'longitude': longitude,
                'area': area,
                'area_unit': area_unit,
                'total_sqft': int(total_sqft),
                'land_type': land_type,
                'road_access': road_access,
                'predicted_price': predicted_price,
                'low_estimate': low_estimate,
                'high_estimate': high_estimate,
                'area_avg_price': area_avg_price,
                'confidence': 92
            }

        except ValueError:
            flash("Please enter valid numeric values for land area and GPS coordinates.", "error")
            
    return render_template('valuation_sandbox.html', result=prediction_result)
