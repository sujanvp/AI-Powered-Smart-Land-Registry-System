import io
import csv
from datetime import datetime, timedelta
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file
from flask_login import login_required, current_user
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfgen import canvas

from models import db
from models.user import User
from models.land import Land
from models.fraud import FraudRecord
from models.ownership import OwnershipHistory

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/admin/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required to access Admin Control Panel.', 'error')
        return redirect(url_for('land.dashboard'))
        
    total_users = User.query.count()
    total_lands = Land.query.count()
    
    pending_lands = Land.query.filter_by(status='pending').order_by(Land.id.desc()).limit(20).all()
    flagged_lands = Land.query.filter_by(status='flagged').order_by(Land.id.desc()).limit(20).all()
    active_frauds = FraudRecord.query.filter_by(status='investigating').order_by(FraudRecord.reported_at.desc()).limit(20).all()
    pending_officers = User.query.filter_by(role='registrar', is_verified=False).limit(20).all()
    
    return render_template(
        'admin.html',
        total_users=total_users,
        total_lands=total_lands,
        pending_lands=pending_lands,
        flagged_lands=flagged_lands,
        active_frauds=active_frauds,
        pending_officers=pending_officers
    )


@admin_bp.route('/admin/officer-approvals')
@login_required
def officer_approvals():
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required to access Officer Approvals.', 'error')
        return redirect(url_for('land.dashboard'))

    pending_officers = User.query.filter(
        User.role == 'registrar',
        db.or_(User.status == 'pending', User.status.is_(None), db.and_(User.is_verified == False, User.status != 'rejected'))
    ).order_by(User.created_at.desc()).all()

    approved_officers = User.query.filter(
        User.role == 'registrar',
        db.or_(User.status == 'approved', db.and_(User.is_verified == True, User.status != 'rejected'))
    ).order_by(User.created_at.desc()).all()

    rejected_officers = User.query.filter(
        User.role == 'registrar',
        User.status == 'rejected'
    ).order_by(User.created_at.desc()).all()

    return render_template(
        'officer_registration_approval.html',
        pending_officers=pending_officers,
        approved_officers=approved_officers,
        rejected_officers=rejected_officers
    )


@admin_bp.route('/admin/officer/approve/<int:user_id>', methods=['POST'])
@login_required
def approve_officer(user_id):
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    officer = User.query.get_or_404(user_id)
    if officer.role == 'registrar':
        officer.is_verified = True
        officer.status = 'approved'
        officer.rejection_reason = None
        officer.rejected_by = None
        officer.rejected_at = None

        # Create Database-backed Notification for Registrar
        from models.notification import Notification
        existing = Notification.query.filter_by(
            user_id=officer.id,
            notification_type='officer_registration_approved'
        ).first()
        if not existing:
            notif = Notification(
                user_id=officer.id,
                title="🔔 Revenue Officer Registration Approved",
                message="Your Revenue Officer registration has been approved. Your account is now active.",
                notification_type="officer_registration_approved",
                related_request_id=officer.id
            )
            db.session.add(notif)

        db.session.commit()
        flash(f"Revenue Officer account '{officer.username}' ({officer.email}) has been approved and activated.", 'success')
    return redirect(request.referrer or url_for('admin.officer_approvals'))


@admin_bp.route('/admin/officer/reject/<int:user_id>', methods=['POST'])
@login_required
def reject_officer(user_id):
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    officer = User.query.get_or_404(user_id)
    reason = (request.form.get('rejection_reason') or request.form.get('notes') or '').strip()
    if not reason:
        flash("Rejection reason is mandatory when rejecting a Revenue Officer registration.", 'error')
        return redirect(request.referrer or url_for('admin.officer_approvals'))

    if officer.role == 'registrar':
        officer.is_verified = False
        officer.status = 'rejected'
        officer.rejection_reason = reason
        officer.rejected_by = f"Admin ({current_user.username})"
        officer.rejected_at = datetime.utcnow()

        # Create Database-backed Notification for Registrar
        from models.notification import Notification
        existing = Notification.query.filter_by(
            user_id=officer.id,
            notification_type='officer_registration_rejected'
        ).first()
        if not existing:
            notif = Notification(
                user_id=officer.id,
                title="🔔 Revenue Officer Registration Rejected",
                message="Your Revenue Officer registration has been rejected.",
                notification_type="officer_registration_rejected",
                related_request_id=officer.id
            )
            db.session.add(notif)

        db.session.commit()
        flash(f"Revenue Officer registration for '{officer.username}' has been marked as Rejected/Inactive.", 'warning')
    return redirect(request.referrer or url_for('admin.officer_approvals'))


@admin_bp.route('/admin/officer/<int:user_id>')
@login_required
def officer_detail(user_id):
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required to access Officer Details.', 'error')
        return redirect(url_for('land.dashboard'))

    officer = User.query.get_or_404(user_id)
    if officer.role != 'registrar':
        flash('Requested user is not a Revenue Officer.', 'warning')
        return redirect(url_for('admin.officer_approvals'))

    if officer.status == 'approved' or (officer.is_verified and officer.status != 'rejected'):
        reg_status_label = 'Approved'
    elif officer.status == 'rejected':
        reg_status_label = 'Rejected'
    else:
        reg_status_label = 'Pending Admin Verification'

    return render_template(
        'officer_detail.html',
        officer=officer,
        reg_status_label=reg_status_label
    )



@admin_bp.route('/admin/officer/toggle-status/<int:user_id>', methods=['POST'])
@login_required
def toggle_officer_status(user_id):
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('land.dashboard'))

    officer = User.query.get_or_404(user_id)
    new_status = request.form.get('status')
    reason = request.form.get('rejection_reason', 'Status modified by Administrator.')

    if officer.role == 'registrar':
        if new_status == 'approved':
            officer.is_verified = True
            officer.status = 'approved'
            officer.rejection_reason = None
            flash(f"Officer '{officer.username}' status changed to Active.", 'success')
        elif new_status == 'rejected':
            officer.is_verified = False
            officer.status = 'rejected'
            officer.rejection_reason = reason
            flash(f"Officer '{officer.username}' status changed to Rejected/Inactive.", 'warning')

        db.session.commit()

    return redirect(request.referrer or url_for('admin.officer_approvals'))


@admin_bp.route('/admin/approve/<int:land_id>', methods=['POST'])
@login_required
def approve_land(land_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied.', 'error')
        return redirect(url_for('land.dashboard'))
        
    land = Land.query.get_or_404(land_id)
    land.status = 'verified'
    land.rejection_reason = None
    
    # Ensure official Land Record and Ownership Record exist
    history = OwnershipHistory.query.filter_by(land_id=land.id, previous_owner_id=None).first()
    if not history:
        transfer_ref = f"REG-{datetime.utcnow().strftime('%Y%m%d')}-{land.id:04d}"
        history = OwnershipHistory(
            land_id=land.id,
            previous_owner_id=None,
            new_owner_id=land.owner_id,
            transfer_price=land.price,
            transfer_ref=transfer_ref
        )
        db.session.add(history)

    for doc in land.documents:
        if doc.verification_status == 'pending':
            doc.verification_status = 'approved'
            doc.verification_notes = f"Verified by Officer {current_user.username} during registry approval."
            
    from routes.land import create_db_notification
    create_db_notification(
        user_id=land.owner_id,
        title="🔔 Land Registration Approved",
        message="Your land registration request has been approved.",
        notification_type="land_registration_approved",
        related_land_id=land.id
    )

    db.session.commit()
    flash(f"Registry Approved: Land ({land.survey_number}) is now officially verified in MySQL database.", 'success')
    return redirect(url_for('admin.dashboard') if current_user.role == 'admin' else url_for('land.pending_approvals'))

@admin_bp.route('/admin/reject/<int:land_id>', methods=['POST'])
@login_required
def reject_land(land_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied.', 'error')
        return redirect(url_for('land.dashboard'))
        
    land = Land.query.get_or_404(land_id)
    reason = request.form.get('rejection_reason', 'Land registration failed Administrator verification inspection.').strip()
    
    land.status = 'rejected'
    land.rejection_reason = reason
    land.rejected_by = f"Admin/Officer ({current_user.username})"
    land.rejected_at = datetime.utcnow()

    from routes.land import create_db_notification
    create_db_notification(
        user_id=land.owner_id,
        title="🔔 Land Registration Rejected",
        message="Your land registration request has been rejected.",
        notification_type="land_registration_rejected",
        related_land_id=land.id
    )
        
    db.session.commit()
    flash(f"Registry Rejected: Land ({land.survey_number}) registration has been rejected.", 'warning')
    return redirect(url_for('admin.dashboard') if current_user.role == 'admin' else url_for('land.pending_approvals'))

@admin_bp.route('/admin/reports')
@login_required
def reports():
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required to access Audit Reports.', 'error')
        return redirect(url_for('land.dashboard'))

    from models.document import Document
    from models.request import LandRequest
    from models.ownership import OwnershipHistory

    total_lands = Land.query.count()
    verified_lands = Land.query.filter_by(status='verified').count()
    flagged_lands = Land.query.filter_by(status='flagged').count()
    pending_lands = Land.query.filter_by(status='pending').count()
    
    total_documents = Document.query.count()
    approved_documents = Document.query.filter_by(verification_status='approved').count()
    rejected_documents = Document.query.filter_by(verification_status='rejected').count()
    pending_documents = Document.query.filter_by(verification_status='pending').count()
    
    total_transfers = OwnershipHistory.query.count()
    total_requests = LandRequest.query.count()
    pending_requests = LandRequest.query.filter_by(status='pending').count()
    approved_requests = LandRequest.query.filter_by(status='approved').count()
    paid_requests = LandRequest.query.filter_by(status='paid').count()

    mock_reports = [
        {"id": "REP-2026-001", "name": "Registry Assets Summary", "type": "PDF", "date": "2026-07-28", "status": "Ready"},
        {"id": "REP-2026-002", "name": "AI Audit & Compliance Audit Log", "type": "CSV", "date": "2026-07-28", "status": "Ready"},
        {"id": "REP-2026-003", "name": "Land Transfer Valuation Index", "type": "XLSX", "date": "2026-07-27", "status": "Ready"},
        {"id": "REP-2026-004", "name": "Security Risk & Anomalies Audit", "type": "PDF", "date": "2026-07-25", "status": "Ready"}
    ]

    return render_template(
        'reports.html',
        total_lands=total_lands,
        verified_lands=verified_lands,
        flagged_lands=flagged_lands,
        pending_lands=pending_lands,
        total_documents=total_documents,
        approved_documents=approved_documents,
        rejected_documents=rejected_documents,
        pending_documents=pending_documents,
        total_transfers=total_transfers,
        total_requests=total_requests,
        pending_requests=pending_requests,
        approved_requests=approved_requests,
        paid_requests=paid_requests,
        reports_list=mock_reports
    )

@admin_bp.route('/admin/analytics')
@login_required
def analytics():
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required to access Registry Analytics.', 'error')
        return redirect(url_for('land.dashboard'))

    from models.ownership import OwnershipHistory
    
    city_stats = db.session.query(
        Land.city,
        db.func.count(Land.id),
        db.func.avg(Land.price)
    ).group_by(Land.city).all()

    city_counts = {}
    avg_prices = {}
    for row in city_stats:
        cname = (row[0] or 'Other').split(',')[0].strip().title()
        city_counts[cname] = city_counts.get(cname, 0) + row[1]
        avg_prices[cname] = float(row[2] or 0)
        
    total_audits = FraudRecord.query.count()
    unresolved_audits = FraudRecord.query.filter_by(status='investigating').count()
    resolved_cleared = FraudRecord.query.filter_by(status='resolved_clear').count()
    resolved_fraud = FraudRecord.query.filter_by(status='confirmed_fraud').count()
    
    total_transfers = OwnershipHistory.query.count()
    recent_transfers = OwnershipHistory.query.order_by(OwnershipHistory.transfer_date.desc()).limit(5).all()
    
    return render_template(
        'analytics.html',
        city_counts=city_counts,
        avg_prices=avg_prices,
        total_audits=total_audits,
        unresolved_audits=unresolved_audits,
        resolved_cleared=resolved_cleared,
        resolved_fraud=resolved_fraud,
        total_transfers=total_transfers,
        recent_transfers=recent_transfers
    )


class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_page_number(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748b"))
        if self._pageNumber > 1:
            self.setStrokeColor(colors.HexColor("#cbd5e1"))
            self.setLineWidth(0.5)
            self.line(36, 756, 576, 756)
            self.drawString(36, 762, "SMART LAND REGISTRY SYSTEM — OFFICIAL AUDIT REPORT")
        self.setStrokeColor(colors.HexColor("#cbd5e1"))
        self.setLineWidth(0.5)
        self.line(36, 36, 576, 36)
        self.drawRightString(576, 24, f"Page {self._pageNumber} of {page_count}")
        self.drawString(36, 24, "CONFIDENTIAL — Government Land Records Security Platform")
        self.restoreState()


@admin_bp.route('/admin/reports/download/<report_id>')
@login_required
def download_report(report_id):
    if current_user.role != 'admin':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('land.dashboard'))

    category = request.args.get('category')
    format_type = request.args.get('format')
    date_scope = request.args.get('date_scope', 'All History')

    from models.document import Document
    from models.ownership import OwnershipHistory

    # Handle pre-defined standard reports
    if report_id == 'REP-2026-001':
        # Name: Registry Assets Summary (PDF)
        lands = Land.query.order_by(Land.created_at.desc()).limit(200).all()
        table_headers = ['Survey Number', 'PID', 'Current Owner', 'Location', 'Area (sq ft)', 'Declared Value', 'Status']
        
        styles = getSampleStyleSheet()
        cell_style = ParagraphStyle('Cell', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.HexColor('#1e293b'))
        header_style = ParagraphStyle('Header', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.white, fontName='Helvetica-Bold')

        table_rows = [[Paragraph(h, header_style) for h in table_headers]]
        for land in lands:
            owner_name = land.owner.username if land.owner else 'Unknown'
            val_str = f"₹{land.price:,.2f}"
            row = [
                Paragraph(land.survey_number or '', cell_style),
                Paragraph(land.pid or 'N/A', cell_style),
                Paragraph(owner_name, cell_style),
                Paragraph(land.city or land.location or '', cell_style),
                Paragraph(f"{land.area:,.1f}", cell_style),
                Paragraph(val_str, cell_style),
                Paragraph((land.status or '').upper(), cell_style)
            ]
            table_rows.append(row)

        return _build_pdf_response(
            report_id="REP-2026-001",
            report_name="Registry Assets Summary",
            category="Land Registration Records",
            date_scope=date_scope,
            table_rows=table_rows,
            col_widths=[80, 85, 75, 75, 55, 75, 55],
            filename="REP-2026-001_Registry_Assets_Summary.pdf"
        )

    elif report_id == 'REP-2026-002':
        # Name: AI Audit & Compliance Audit Log (CSV)
        docs = Document.query.order_by(Document.uploaded_at.desc()).limit(500).all()
        
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Document ID', 'Survey Number', 'Uploaded By', 'Verification Status', 'Verification Notes', 'Uploaded Date'])
        
        for d in docs:
            survey = d.land.survey_number if d.land else 'N/A'
            uploader = (d.land.owner.username if (d.land and d.land.owner) else 'System Audit')
            date_str = d.uploaded_at.strftime('%Y-%m-%d %H:%M:%S') if d.uploaded_at else ''
            writer.writerow([d.id, survey, uploader, d.verification_status, d.verification_notes or '', date_str])
            
        mem = io.BytesIO()
        mem.write(output.getvalue().encode('utf-8'))
        mem.seek(0)
        return send_file(
            mem,
            mimetype='text/csv',
            as_attachment=True,
            download_name='REP-2026-002_AI_Audit_Compliance_Audit_Log.csv'
        )

    elif report_id == 'REP-2026-003':
        # Name: Land Transfer Valuation Index (XLSX)
        transfers = OwnershipHistory.query.order_by(OwnershipHistory.transfer_date.desc()).limit(500).all()
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Transfer Valuation"
        
        headers = ['Transfer Ref', 'Survey Number', 'Seller / Previous Owner', 'Buyer / Current Owner', 'Transfer Price (INR)', 'Transfer Date']
        ws.append(headers)
        
        header_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
        header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
        
        for col_num, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            
        for tr in transfers:
            survey = tr.land.survey_number if tr.land else 'N/A'
            prev_owner = tr.previous_owner.username if tr.previous_owner else 'Initial Registration'
            new_owner = tr.new_owner.username if tr.new_owner else 'N/A'
            price = tr.transfer_price or (tr.land.price if tr.land else 0)
            t_date = tr.transfer_date.strftime('%Y-%m-%d %H:%M') if tr.transfer_date else ''
            ws.append([tr.transfer_ref or f"TRF-{tr.id}", survey, prev_owner, new_owner, price, t_date])
            
        for col in ws.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            col_letter = openpyxl.utils.get_column_letter(col[0].column)
            ws.column_dimensions[col_letter].width = max(max_len + 3, 12)
            
        mem = io.BytesIO()
        wb.save(mem)
        mem.seek(0)
        return send_file(
            mem,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='REP-2026-003_Land_Transfer_Valuation_Index.xlsx'
        )

    elif report_id == 'REP-2026-004':
        # Name: Security Risk & Anomalies Audit (PDF)
        frauds = FraudRecord.query.order_by(FraudRecord.reported_at.desc()).limit(200).all()
        table_headers = ['Alert ID', 'Survey #', 'PID', 'Risk Score', 'Flagged Anomalies', 'Audit Status', 'Reported On']
        
        styles = getSampleStyleSheet()
        cell_style = ParagraphStyle('Cell', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.HexColor('#1e293b'))
        header_style = ParagraphStyle('Header', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.white, fontName='Helvetica-Bold')

        table_rows = [[Paragraph(h, header_style) for h in table_headers]]
        for fr in frauds:
            survey = fr.land.survey_number if fr.land else 'N/A'
            pid = fr.land.pid if fr.land else 'N/A'
            flags = ', '.join(fr.fraud_flags or [])
            score_str = f"{int((fr.risk_score or 0) * 100)}%"
            r_date = fr.reported_at.strftime('%Y-%m-%d %H:%M') if fr.reported_at else ''
            row = [
                Paragraph(f"FRD-{fr.id}", cell_style),
                Paragraph(survey, cell_style),
                Paragraph(pid, cell_style),
                Paragraph(score_str, cell_style),
                Paragraph(flags or 'Anomaly Detected', cell_style),
                Paragraph((fr.status or '').upper(), cell_style),
                Paragraph(r_date, cell_style)
            ]
            table_rows.append(row)

        return _build_pdf_response(
            report_id="REP-2026-004",
            report_name="Security Risk & Anomalies Audit",
            category="Fraud Detection Reports",
            date_scope=date_scope,
            table_rows=table_rows,
            col_widths=[55, 75, 85, 55, 140, 60, 70],
            filename="REP-2026-004_Security_Risk_Anomalies_Audit.pdf"
        )
    else:
        # Dynamic report export handler
        cat = category or "Registry Audit Report"
        fmt = (format_type or "PDF").lower()
        safe_cat = cat.replace(' ', '_').replace('&', 'and')
        
        if 'pdf' in fmt:
            lands = Land.query.limit(150).all()
            styles = getSampleStyleSheet()
            cell_style = ParagraphStyle('Cell', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.HexColor('#1e293b'))
            header_style = ParagraphStyle('Header', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.white, fontName='Helvetica-Bold')
            
            table_headers = ['Survey Number', 'PID', 'Current Owner', 'Location', 'Area (sq ft)', 'Value (INR)', 'Status']
            table_rows = [[Paragraph(h, header_style) for h in table_headers]]
            for land in lands:
                owner_name = land.owner.username if land.owner else 'Unknown'
                table_rows.append([
                    Paragraph(land.survey_number or '', cell_style),
                    Paragraph(land.pid or 'N/A', cell_style),
                    Paragraph(owner_name, cell_style),
                    Paragraph(land.city or land.location or '', cell_style),
                    Paragraph(f"{land.area:,.1f}", cell_style),
                    Paragraph(f"₹{land.price:,.2f}", cell_style),
                    Paragraph((land.status or '').upper(), cell_style)
                ])
            return _build_pdf_response(
                report_id=report_id,
                report_name=cat,
                category=cat,
                date_scope=date_scope,
                table_rows=table_rows,
                col_widths=[80, 85, 75, 75, 55, 75, 55],
                filename=f"{report_id}_{safe_cat}.pdf"
            )
        elif 'xlsx' in fmt or 'excel' in fmt:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = cat[:30]
            lands = Land.query.limit(200).all()
            ws.append(['Survey Number', 'PID', 'Owner', 'Location', 'Area (sq ft)', 'Declared Price', 'Status'])
            for l in lands:
                ws.append([l.survey_number, l.pid, l.owner.username if l.owner else '', l.city or l.location, l.area, l.price, l.status])
            mem = io.BytesIO()
            wb.save(mem)
            mem.seek(0)
            return send_file(mem, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', as_attachment=True, download_name=f"{report_id}_{safe_cat}.xlsx")
        else:
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(['Survey Number', 'PID', 'Owner', 'Location', 'Area', 'Price', 'Status'])
            lands = Land.query.limit(200).all()
            for l in lands:
                writer.writerow([l.survey_number, l.pid, l.owner.username if l.owner else '', l.city or l.location, l.area, l.price, l.status])
            mem = io.BytesIO()
            mem.write(output.getvalue().encode('utf-8'))
            mem.seek(0)
            return send_file(mem, mimetype='text/csv', as_attachment=True, download_name=f"{report_id}_{safe_cat}.csv")


def _build_pdf_response(report_id, report_name, category, date_scope, table_rows, col_widths, filename):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=45,
        bottomMargin=45
    )
    
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], fontSize=16, leading=20, textColor=colors.HexColor('#1e3a8a'), fontName='Helvetica-Bold')
    sub_style = ParagraphStyle('SubStyle', parent=styles['Normal'], fontSize=11, leading=14, textColor=colors.HexColor('#475569'), fontName='Helvetica-Bold')
    meta_label_style = ParagraphStyle('MetaLabel', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#64748b'), fontName='Helvetica-Bold')
    meta_val_style = ParagraphStyle('MetaVal', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#0f172a'), fontName='Helvetica')

    story = []
    
    story.append(Paragraph("SMART LAND REGISTRY SYSTEM", title_style))
    story.append(Paragraph(f"Official Audit Report — {report_name}", sub_style))
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#1e3a8a'), spaceBefore=2, spaceAfter=10))
    
    now_str = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    meta_data = [
        [
            Paragraph("Report ID:", meta_label_style), Paragraph(report_id, meta_val_style),
            Paragraph("Generated Date & Time:", meta_label_style), Paragraph(now_str, meta_val_style)
        ],
        [
            Paragraph("Report Category:", meta_label_style), Paragraph(category, meta_val_style),
            Paragraph("Date Scope:", meta_label_style), Paragraph(date_scope or "All Registry History", meta_val_style)
        ],
        [
            Paragraph("Total Records:", meta_label_style), Paragraph(str(len(table_rows) - 1), meta_val_style),
            Paragraph("Classification:", meta_label_style), Paragraph("OFFICIAL / GOVERNMENT CONFIDENTIAL", meta_val_style)
        ]
    ]
    
    meta_table = Table(meta_data, colWidths=[90, 180, 110, 160])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8fafc')),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#f1f5f9')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ]))
    
    story.append(meta_table)
    story.append(Spacer(1, 14))
    
    data_table = Table(table_rows, colWidths=col_widths, repeatRows=1)
    
    t_style = [
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1e3a8a')),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
    ]
    
    for i in range(1, len(table_rows)):
        if i % 2 == 0:
            t_style.append(('BACKGROUND', (0, i), (-1, i), colors.HexColor('#f8fafc')))
        else:
            t_style.append(('BACKGROUND', (0, i), (-1, i), colors.white))
            
    data_table.setStyle(TableStyle(t_style))
    story.append(data_table)
    
    doc.build(story, canvasmaker=NumberedCanvas)
    buffer.seek(0)
    
    return send_file(
        buffer,
        mimetype='application/pdf',
        as_attachment=True,
        download_name=filename
    )



