import os
import hashlib
import time
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from models import db
from models.user import User
from models.land import Land
from models.document import Document
from ml.document_verification import verify_document_content

doc_bp = Blueprint('document', __name__)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

@doc_bp.route('/land/<int:land_id>/document/upload', methods=['GET', 'POST'])
@login_required
def upload_document(land_id):
    if current_user.role not in ['citizen', 'admin']:
        flash('Access denied. Officers cannot upload documents.', 'error')
        return redirect(url_for('admin.dashboard'))
    land = Land.query.get_or_404(land_id)
    
    # Check ownership (unless administrator or registrar)
    if land.owner_id != current_user.id and current_user.role not in ['registrar', 'admin']:
        flash('Unauthorized to upload documents for this land.', 'error')
        return redirect(url_for('land.dashboard'))
        
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part in the request.', 'error')
            return redirect(request.url)
            
        file = request.files['file']
        doc_type = request.form.get('document_type')
        
        if file.filename == '':
            flash('No file selected.', 'error')
            return redirect(request.url)
            
        if file and allowed_file(file.filename):
            filename = f"{int(time.time())}_{secure_filename(file.filename)}"
            
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # 1. Compute SHA-256 Hash of the file
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            file_hash = sha256_hash.hexdigest()
            
            # 2. Run OCR verification simulator
            owner = User.query.get(land.owner_id)
            owner_name = owner.username if owner else "Unknown"
            
            # Run heuristic check
            is_valid, notes, discrepancy = verify_document_content(
                file_path=file_path,
                expected_survey_number=land.survey_number,
                expected_owner_name=owner_name,
                expected_area=land.area
            )
            
            status = 'approved' if is_valid else 'rejected'
            
            # Create Document instance
            new_doc = Document(
                land_id=land.id,
                document_type=doc_type,
                file_path=f"static/uploads/{filename}", # Store normalized relative path
                hash_value=file_hash,
                verification_status=status,
                verification_notes=notes
            )
            
            db.session.add(new_doc)
            
            # If doc is rejected, let's flag the land
            if status == 'rejected':
                land.status = 'flagged'
                
                # Check if fraud record already exists
                from models.fraud import FraudRecord
                from ml.fraud_detection import detect_fraud
                
                # Create a fraud record for document failure
                fraud_rec = FraudRecord(
                    land_id=land.id,
                    risk_score=0.85, # High risk for failed documents
                    status='investigating',
                    ai_feedback=f"AI System: Document Verification Failed. Reason: {notes}."
                )
                fraud_rec.fraud_flags = ['Document Verification Mismatch']
                db.session.add(fraud_rec)
                
                flash('Document uploaded. ALERT: File failed OCR verification. Land flagged for investigation.', 'warning')
            else:
                flash('Document uploaded and successfully verified via OCR!', 'success')
                
            db.session.commit()
            return redirect(url_for('land.view_land', land_id=land.id))
            
        else:
            flash('Invalid file extension. Allowed: pdf, png, jpg, jpeg, txt', 'error')
            return redirect(request.url)
            
    return render_template('upload_document.html', land=land)


import mimetypes
from flask import send_file

@doc_bp.route('/document/<int:doc_id>/view')
@login_required
def view_document(doc_id):
    doc = Document.query.get(doc_id)
    if not doc or not doc.file_path:
        flash("Document record not found in registry database.", "error")
        return render_template('error.html', error_code=404, error_message="Document Not Found", error_description="Document file is not available."), 404
        
    return serve_deed_file(doc.file_path)


@doc_bp.route('/document/view-path')
@login_required
def view_document_by_path():
    rel_path = request.args.get('path', '').strip()
    if not rel_path:
        flash("Document file is not available.", "error")
        return render_template('error.html', error_code=404, error_message="Document Not Found", error_description="Document file is not available."), 404
        
    return serve_deed_file(rel_path)


def serve_deed_file(rel_path):
    if not rel_path:
        return render_template('error.html', 
                               error_code=404, 
                               error_message="Document Not Found", 
                               error_description="Deed document is not available."), 404
                               
    clean_rel_path = rel_path.replace('\\', '/').lstrip('/')
    
    # Directory traversal prevention
    if '..' in clean_rel_path:
        return render_template('error.html', 
                               error_code=403, 
                               error_message="Access Denied", 
                               error_description="Invalid document path requested."), 403

    if clean_rel_path.startswith('static/'):
        clean_rel_path_no_static = clean_rel_path[7:].lstrip('/')
    else:
        clean_rel_path_no_static = clean_rel_path
        
    upload_folder = current_app.config['UPLOAD_FOLDER']
    base_dir = current_app.config['BASE_DIR']
    
    filename = os.path.basename(clean_rel_path)
    candidates = [
        os.path.join(upload_folder, filename),
        os.path.join(base_dir, clean_rel_path),
        os.path.join(base_dir, 'static', clean_rel_path_no_static),
        os.path.join(upload_folder, clean_rel_path_no_static)
    ]
    
    target_path = None
    for candidate in candidates:
        abs_candidate = os.path.abspath(candidate)
        # Ensure target file stays strictly within project base directory
        if abs_candidate.startswith(os.path.abspath(base_dir)) and os.path.exists(abs_candidate) and os.path.isfile(abs_candidate):
            target_path = abs_candidate
            break
            
    if not target_path:
        return render_template('error.html', 
                               error_code=404, 
                               error_message="Document Not Available", 
                               error_description="No Physical Deed File Available for This Generated Record"), 404

    mime, _ = mimetypes.guess_type(target_path)
    ext = os.path.splitext(target_path)[1].lower()
    
    if ext == '.pdf':
        mime = 'application/pdf'
    elif ext in ['.jpg', '.jpeg']:
        mime = 'image/jpeg'
    elif ext == '.png':
        mime = 'image/png'
    elif ext == '.webp':
        mime = 'image/webp'
    elif ext == '.txt':
        mime = 'text/plain'
    elif not mime:
        mime = 'application/octet-stream'

    return send_file(
        target_path,
        mimetype=mime,
        as_attachment=False,
        download_name=filename
    )
