import os
import hashlib
import time
import random
import json
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from models import db
from models.user import User
from models.land import Land
from models.ownership import OwnershipHistory
from models.fraud import FraudRecord
from models.prediction import PricePrediction
from models.document import Document
from models.request import LandRequest
from ml.land_price_prediction import predict_land_price
from ml.fraud_detection import detect_fraud
from ml.ownership_risk import calculate_ownership_risk
from ml.document_verification import verify_document_content

def create_db_notification(user_id, title, message, notification_type, related_request_id=None, related_land_id=None):
    from models.notification import Notification
    existing = Notification.query.filter_by(
        user_id=user_id,
        notification_type=notification_type,
        related_request_id=related_request_id,
        related_land_id=related_land_id
    ).first()
    if existing:
        return existing
    notif = Notification(
        user_id=user_id,
        title=title,
        message=message,
        notification_type=notification_type,
        related_request_id=related_request_id,
        related_land_id=related_land_id
    )
    db.session.add(notif)
    return notif

land_bp = Blueprint('land', __name__)

@land_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        return redirect(url_for('admin.dashboard'))
        
    total_citizens = User.query.filter_by(role='citizen').count() or 0
    registered_lands_count = Land.query.count() or 0
    total_requests = LandRequest.query.count() or 0
    
    my_lands_count = Land.query.filter_by(owner_id=current_user.id).count()
    my_pending_requests_count = LandRequest.query.filter(
        ((LandRequest.seller_id == current_user.id) | (LandRequest.buyer_id == current_user.id)),
        LandRequest.status == 'pending'
    ).count()
    
    my_transfer_requests = LandRequest.query.filter(
        (LandRequest.seller_id == current_user.id) | (LandRequest.buyer_id == current_user.id)
    ).order_by(LandRequest.created_at.desc()).limit(10).all()
    
    my_lands = Land.query.filter_by(owner_id=current_user.id).limit(10).all()
    
    from models.document import Document
    if my_lands_count > 0:
        user_land_ids = [l[0] for l in db.session.query(Land.id).filter_by(owner_id=current_user.id).all()]
        verified_docs_count = Document.query.filter(
            Document.land_id.in_(user_land_ids),
            Document.verification_status == 'approved'
        ).count()
    else:
        verified_docs_count = 0

    
    return render_template(
        'dashboard.html',
        total_citizens=total_citizens,
        registered_lands_count=registered_lands_count,
        total_requests=total_requests,
        my_lands_count=my_lands_count,
        my_pending_requests_count=my_pending_requests_count,
        verified_docs_count=verified_docs_count,
        my_transfer_requests=my_transfer_requests,
        my_lands=my_lands
    )


@land_bp.route('/land/register', methods=['GET', 'POST'])
@login_required
def register_land():
    if current_user.role not in ['citizen', 'admin']:
        flash('Access denied. Only citizens can register lands.', 'error')
        return redirect(url_for('admin.dashboard'))
        
    if request.method == 'POST':
        area_str = request.form.get('area')
        city = request.form.get('city')
        state = request.form.get('state')
        price_str = request.form.get('price')
        pid = request.form.get('pid')
        survey_number = request.form.get('survey_number')
        
        area = float(area_str) if area_str else 0.0
        price = float(price_str) if price_str else 0.0
        
        # Check unique survey number in MySQL
        exists = Land.query.filter_by(survey_number=survey_number).first()
        if exists:
            flash('Survey number already registered in MySQL registry.', 'error')
            return redirect(url_for('land.register_land'))
            
        city_coords = {
            'akola': (20.7002, 77.0082),
            'mumbai': (19.0760, 72.8777),
            'pune': (18.5204, 73.8567),
            'nagpur': (21.1458, 79.0882),
            'thane': (19.2183, 72.9781),
            'nashik': (19.9975, 73.7898),
            'aurangabad': (19.8762, 75.3433),
            'solapur': (17.6599, 75.9064),
            'amravati': (20.9374, 77.7796),
            'nanded': (19.1383, 77.3210),
            'kolhapur': (16.7050, 74.2433)
        }
        lat, lon = city_coords.get(city.lower().strip(), (18.5204 + random.uniform(-0.05, 0.05), 73.8567 + random.uniform(-0.05, 0.05)))
        location_str = f"{city}, {state}"
        
        land_image_file = request.files.get('land_image')
        aadhar_document_file = request.files.get('aadhar_document')
        
        image_path = None
        aadhar_path = None
        
        if land_image_file and land_image_file.filename != '':
            img_filename = f"{int(time.time())}_{secure_filename(land_image_file.filename)}"
            img_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], img_filename)
            land_image_file.save(img_save_path)
            image_path = f"static/uploads/{img_filename}"
            
        if aadhar_document_file and aadhar_document_file.filename != '':
            doc_filename = f"{int(time.time())}_{secure_filename(aadhar_document_file.filename)}"
            doc_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], doc_filename)
            aadhar_document_file.save(doc_save_path)
            aadhar_path = f"static/uploads/{doc_filename}"

        new_land = Land(
            survey_number=survey_number,
            owner_id=current_user.id,
            area=area,
            location=location_str,
            latitude=lat,
            longitude=lon,
            status='pending',
            price=price,
            description=f"PID: {pid}. Registered in {city}, {state}.",
            pid=pid,
            city=city,
            state=state,
            image_path=image_path,
            aadhar_path=aadhar_path
        )
        
        db.session.add(new_land)
        db.session.commit()
        
        # 1. Document Verification (Tesseract OCR)
        doc_discrepancy = 0
        if aadhar_path:
            sha256_hash = hashlib.sha256()
            full_doc_path = os.path.join(current_app.config['BASE_DIR'], aadhar_path)
            if os.path.exists(full_doc_path):
                with open(full_doc_path, "rb") as f:
                    for byte_block in iter(lambda: f.read(4096), b""):
                        sha256_hash.update(byte_block)
            file_hash = sha256_hash.hexdigest()
            
            is_valid, notes, discrepancy = verify_document_content(
                file_path=full_doc_path,
                expected_survey_number=survey_number,
                expected_owner_name=current_user.username,
                expected_area=area
            )
            doc_discrepancy = discrepancy
            doc_status = 'approved' if is_valid else 'rejected'
            
            new_doc = Document(
                land_id=new_land.id,
                document_type='title_deed',
                file_path=aadhar_path,
                hash_value=file_hash,
                verification_status=doc_status,
                verification_notes=notes
            )
            db.session.add(new_doc)
            db.session.commit()
            
        # 2. Property Price Prediction (ML Model)
        price_model_path = os.path.join(current_app.config['ML_MODEL_FOLDER'], 'price_model.pkl')
        pred_price, low_est, high_est, r2 = predict_land_price(city, area, lat, lon, price_model_path)
        
        prediction = PricePrediction(
            land_id=new_land.id,
            predicted_price=pred_price,
            low_estimate=low_est,
            high_estimate=high_est,
            confidence_score=r2
        )
        db.session.add(prediction)
        
        # 3. Land Records & Ownership History (MySQL Entry)
        transfer_ref = f"REG-{datetime.utcnow().strftime('%Y%m%d')}-{new_land.id:04d}"
        history = OwnershipHistory(
            land_id=new_land.id,
            previous_owner_id=None,
            new_owner_id=current_user.id,
            transfer_price=price,
            transfer_ref=transfer_ref
        )
        db.session.add(history)
        db.session.commit()
        
        # 5. Database Notification for Citizen (Land Registration Pending)
        create_db_notification(
            user_id=current_user.id,
            title="🔔 Land Registration Pending",
            message="Your land registration request is pending verification.",
            notification_type="land_registration_pending",
            related_land_id=new_land.id
        )
        db.session.commit()

        fraud_model_path = os.path.join(current_app.config['ML_MODEL_FOLDER'], 'fraud_model.pkl')
        price_var = new_land.price / pred_price if pred_price > 0 else 1.0
        fraud_prob, flags = detect_fraud(
            price_variance=price_var,
            days_since_last_transfer=365,
            num_transfers_last_year=0,
            doc_discrepancy=doc_discrepancy,
            model_path=fraud_model_path
        )

        if fraud_prob > 0.5 or flags:
            new_land.status = 'flagged'
            fraud_rec = FraudRecord(
                land_id=new_land.id,
                risk_score=fraud_prob,
                fraud_flags=flags,
                status='investigating',
                ai_feedback=f"AI Fraud Detection Flag: Risk factor(s): {', '.join(flags)}."
            )
            db.session.add(fraud_rec)
            db.session.commit()
            flash('Land registered in MySQL DB. Warning: AI flagged potential anomaly.', 'warning')
        else:
            flash('Land registered successfully in MySQL Registry! Pending officer review.', 'success')
            
        return redirect(url_for('land.dashboard'))
        
    return render_template('register_land.html')

@land_bp.route('/land/<int:land_id>')
@login_required
def view_land(land_id):
    land = Land.query.get_or_404(land_id)
    history = OwnershipHistory.query.filter_by(land_id=land.id).order_by(OwnershipHistory.transfer_date.desc()).all()
    prediction = PricePrediction.query.filter_by(land_id=land.id).order_by(PricePrediction.prediction_date.desc()).first()
    risk_score, risk_level, risk_factors = calculate_ownership_risk(land)
    fraud_records = FraudRecord.query.filter_by(land_id=land.id).all()
    
    return render_template(
        'land_detail.html',
        land=land,
        history=history,
        prediction=prediction,
        risk_score=int(risk_score * 100),
        risk_level=risk_level,
        risk_factors=risk_factors,
        fraud_records=fraud_records
    )

@land_bp.route('/owned-lands')
@login_required
def owned_lands():
    page = request.args.get('page', 1, type=int)
    pagination = Land.query.filter_by(owner_id=current_user.id).order_by(Land.id.desc()).paginate(page=page, per_page=20, error_out=False)
    lands = pagination.items
    lands_with_risk = []
    for land in lands:
        risk_score, risk_level, _ = calculate_ownership_risk(land)
        lands_with_risk.append({
            'info': land,
            'risk_score': int(risk_score * 100),
            'risk_level': risk_level
        })
    return render_template('owned_lands.html', lands=lands_with_risk, pagination=pagination)


@land_bp.route('/land/<int:land_id>/transfer', methods=['GET', 'POST'])
@login_required
def transfer_land(land_id):
    land = Land.query.get_or_404(land_id)
    if land.owner_id != current_user.id and current_user.role != 'admin':
        flash('Unauthorized. You can only transfer properties that you own.', 'error')
        return redirect(url_for('land.owned_lands'))
        
    if request.method == 'POST':
        buyer_citizen_id = (request.form.get('buyer_citizen_id') or request.form.get('buyer_identifier') or '').strip()
        transfer_reason = request.form.get('transfer_reason', 'Sale').strip()
        declared_price_raw = request.form.get('declared_price') or request.form.get('bid_price')
        try:
            declared_price = float(declared_price_raw) if declared_price_raw else land.price
        except (ValueError, TypeError):
            declared_price = land.price

        doc_file = request.files.get('transfer_document')
        
        # Find buyer by Citizen ID, Username, or Email
        buyer = User.query.filter(
            (User.citizen_id == buyer_citizen_id) | 
            (User.username == buyer_citizen_id) | 
            (User.email == buyer_citizen_id)
        ).first()
        
        if not buyer:
            flash("Citizen ID not found.", 'error')
            return redirect(url_for('land.transfer_land', land_id=land.id))
            
        if buyer.id == current_user.id:
            flash("You cannot transfer property ownership to yourself.", 'error')
            return redirect(url_for('land.transfer_land', land_id=land.id))
            
        # Check existing pending request
        existing_req = LandRequest.query.filter_by(land_id=land.id, status='pending').first()
        if existing_req:
            flash("A transfer request for this property is already pending Registrar approval.", 'warning')
            return redirect(url_for('land.transfer_requests'))
            
        doc_path = None
        if doc_file and doc_file.filename != '':
            filename = f"transfer_{int(time.time())}_{secure_filename(doc_file.filename)}"
            save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            doc_file.save(save_path)
            doc_path = f"static/uploads/{filename}"
            
            # OCR verification on uploaded document
            full_path = os.path.join(current_app.config['BASE_DIR'], doc_path)
            sha256_hash = hashlib.sha256()
            if os.path.exists(full_path):
                with open(full_path, "rb") as f:
                    for byte_block in iter(lambda: f.read(4096), b""):
                        sha256_hash.update(byte_block)
            file_hash = sha256_hash.hexdigest()
            
            is_valid, notes, discrepancy = verify_document_content(
                file_path=full_path,
                expected_survey_number=land.survey_number,
                expected_owner_name=current_user.username,
                expected_area=land.area
            )
            doc_status = 'approved' if is_valid else 'rejected'
            
            new_doc = Document(
                land_id=land.id,
                document_type='transfer_deed',
                file_path=doc_path,
                hash_value=file_hash,
                verification_status=doc_status,
                verification_notes=f"OCR Check: {notes}"
            )
            db.session.add(new_doc)
            
        transfer_req = LandRequest(
            land_id=land.id,
            seller_id=current_user.id,
            buyer_id=buyer.id,
            seller_citizen_id=current_user.citizen_id,
            buyer_citizen_id=buyer.citizen_id,
            bid_price=declared_price,
            transfer_reason=transfer_reason,
            transfer_doc_path=doc_path,
            status='pending'
        )
        land.status = 'pending'
        
        db.session.add(transfer_req)
        db.session.commit()
        
        # Pending Notifications for Land Transfer
        create_db_notification(
            user_id=current_user.id,
            title="🔔 Land Transfer Pending",
            message="Your land transfer request is pending approval.",
            notification_type="land_transfer_pending",
            related_request_id=transfer_req.id,
            related_land_id=land.id
        )
        if buyer.id != current_user.id:
            create_db_notification(
                user_id=buyer.id,
                title="🔔 Land Transfer Pending",
                message="Your land transfer request is pending approval.",
                notification_type="land_transfer_pending",
                related_request_id=transfer_req.id,
                related_land_id=land.id
            )
        db.session.commit()

        flash(f"Transfer Request ({transfer_reason}) for Land ({land.survey_number}) submitted successfully to '{buyer.username}' ({buyer.citizen_id}). Awaiting Registrar approval.", 'success')
        return redirect(url_for('land.transfer_requests'))
        
    risk_score, risk_level, risk_factors = calculate_ownership_risk(land)
    latest_doc = Document.query.filter_by(land_id=land.id).order_by(Document.uploaded_at.desc()).first()
    ocr_status = (latest_doc.verification_status if latest_doc else 'approved').upper()
    fraud_rec = FraudRecord.query.filter_by(land_id=land.id).first()
    fraud_status = (fraud_rec.status if fraud_rec else 'cleared').upper()

    req_count = LandRequest.query.count() + 1
    transfer_ref = f"TRF-{datetime.utcnow().year}-{req_count:04d}"

    return render_template(
        'transfer_land.html',
        land=land,
        transfer_ref=transfer_ref,
        risk_score=int(risk_score * 100),
        risk_level=risk_level,
        ocr_status=ocr_status,
        fraud_status=fraud_status
    )

@land_bp.route('/api/citizen-info/<citizen_id>')
@login_required
def citizen_info(citizen_id):
    c_id = citizen_id.strip()
    user = User.query.filter(
        (User.citizen_id == c_id) | (User.username == c_id) | (User.email == c_id)
    ).first()
    if user:
        return jsonify({
            'success': True,
            'citizen_id': user.citizen_id,
            'name': user.username,
            'email': user.email
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Citizen ID not found.'
        }), 404

@land_bp.route('/transfer-requests')
@login_required
def transfer_requests():
    page = request.args.get('page', 1, type=int)
    if current_user.role in ['registrar', 'admin']:
        pagination = LandRequest.query.order_by(LandRequest.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    else:
        pagination = LandRequest.query.filter(
            (LandRequest.seller_id == current_user.id) | (LandRequest.buyer_id == current_user.id)
        ).order_by(LandRequest.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
        
    return render_template('transfer_requests.html', requests=pagination.items, pagination=pagination)

@land_bp.route('/land-registration-approvals')
@login_required
def land_registration_approvals():
    if current_user.role != 'registrar':
        flash('Access denied. Land Registration Approvals is restricted to Registrar.', 'error')
        return redirect(url_for('land.dashboard'))
        
    page = request.args.get('page', 1, type=int)
    pagination = Land.query.order_by(Land.id.desc()).paginate(page=page, per_page=20, error_out=False)
    lands = pagination.items
    
    registration_items = []
    fraud_model_path = os.path.join(current_app.config['ML_MODEL_FOLDER'], 'fraud_model.pkl')
    
    for land in lands:
        doc = Document.query.filter_by(land_id=land.id).order_by(Document.uploaded_at.desc()).first()
        doc_status = doc.verification_status if doc else 'no_document'
        doc_notes = doc.verification_notes if doc else ''
        
        pred = PricePrediction.query.filter_by(land_id=land.id).order_by(PricePrediction.prediction_date.desc()).first()
        pred_price = pred.predicted_price if pred else land.price
        price_var = land.price / pred_price if pred_price > 0 else 1.0
        doc_disc = 1 if doc_status == 'rejected' else 0
        
        prob, flags = detect_fraud(
            price_variance=price_var,
            days_since_last_transfer=365,
            num_transfers_last_year=0,
            doc_discrepancy=doc_disc,
            model_path=fraud_model_path
        )
        
        fraud_rec = FraudRecord.query.filter_by(land_id=land.id).first()
        if fraud_rec and fraud_rec.risk_score > prob:
            prob = fraud_rec.risk_score
            flags = list(set(flags + (fraud_rec.fraud_flags or [])))
            
        registration_items.append({
            'land': land,
            'doc': doc,
            'doc_status': doc_status,
            'doc_notes': doc_notes,
            'fraud_prob': int(prob * 100),
            'flags': flags
        })
        
    return render_template('land_registration_approvals.html', registration_items=registration_items, pagination=pagination)


@land_bp.route('/land/<int:land_id>/approve-registration', methods=['POST'])
@login_required
def approve_registration(land_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Registrar authority required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    land = Land.query.get_or_404(land_id)
    land.status = 'approved'
    land.rejection_reason = None
    
    # Ensure official Land Record and Ownership Record exist
    history = OwnershipHistory.query.filter_by(land_id=land.id, previous_owner_id=None).first()
    if not history:
        transfer_ref = f"REG-{datetime.utcnow().strftime('%Y%m%d')}-{land.id:04d}"
        history = OwnershipHistory(
            land_id=land.id,
            previous_owner_id=None,
            new_owner_id=land.owner_id,
            transfer_price=land.price,
            transfer_ref=transfer_ref
        )
        db.session.add(history)
        
    for doc in land.documents:
        if doc.verification_status != 'approved':
            doc.verification_status = 'approved'
            doc.verification_notes = f"Verified & Approved by Registrar {current_user.username}"
            
    # Notification for Citizen
    create_db_notification(
        user_id=land.owner_id,
        title="🔔 Land Registration Approved",
        message="Your land registration request has been approved.",
        notification_type="land_registration_approved",
        related_land_id=land.id
    )

    db.session.commit()
    flash(f"LAND REGISTRATION APPROVED! Land {land.survey_number} is now officially registered in MySQL Registry.", 'success')
    return redirect(url_for('land.land_registration_approvals'))


@land_bp.route('/land/<int:land_id>/reject-registration', methods=['POST'])
@login_required
def reject_registration(land_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Registrar authority required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    land = Land.query.get_or_404(land_id)
    reason = request.form.get('rejection_reason', '').strip()
    if not reason:
        flash('Rejection reason is mandatory when rejecting a land registration request.', 'error')
        return redirect(url_for('land.land_registration_approvals'))
    
    land.status = 'rejected'
    land.rejection_reason = reason
    land.rejected_by = f"Registrar ({current_user.username})"
    land.rejected_at = datetime.utcnow()
    
    # Create Citizen Notification
    create_db_notification(
        user_id=land.owner_id,
        title="🔔 Land Registration Rejected",
        message="Your land registration request has been rejected.",
        notification_type="land_registration_rejected",
        related_land_id=land.id
    )
    
    db.session.commit()
    flash(f"Land Registration Request for {land.survey_number} has been Rejected. Reason saved and Citizen notified.", 'warning')
    return redirect(url_for('land.land_registration_approvals'))


@land_bp.route('/land/<int:land_id>/flag-registration', methods=['POST'])
@login_required
def flag_registration(land_id):
    if current_user.role != 'registrar':
        flash('Access denied. Registrar authority required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    land = Land.query.get_or_404(land_id)
    land.status = 'flagged'
    
    fraud_rec = FraudRecord.query.filter_by(land_id=land.id).first()
    if not fraud_rec:
        fraud_rec = FraudRecord(
            land_id=land.id,
            risk_score=0.70,
            status='investigating',
            ai_feedback=f"Flagged for manual Registrar review by {current_user.username}."
        )
        db.session.add(fraud_rec)
        
    db.session.commit()
    flash(f"Land Registration Request for {land.survey_number} FLAGGED FOR REVIEW.", 'warning')
    return redirect(url_for('land.land_registration_approvals'))


@land_bp.route('/pending-transfer-approvals')
@land_bp.route('/pending-approvals')
@login_required
def pending_transfer_approvals():
    if current_user.role != 'registrar':
        flash('Access denied. Pending Transfer Approvals is restricted to Registrar.', 'error')
        return redirect(url_for('land.dashboard'))
        
    page = request.args.get('page', 1, type=int)
    pagination = LandRequest.query.filter(LandRequest.status.in_(['pending', 'flagged'])).order_by(LandRequest.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    pending_list = pagination.items
    
    pending_with_ai = []
    fraud_model_path = os.path.join(current_app.config['ML_MODEL_FOLDER'], 'fraud_model.pkl')
    
    for req in pending_list:
        land = req.land
        pred = PricePrediction.query.filter_by(land_id=land.id).order_by(PricePrediction.prediction_date.desc()).first()
        pred_price = pred.predicted_price if pred else land.price
        price_var = land.price / pred_price if pred_price > 0 else 1.0
        
        last_history = OwnershipHistory.query.filter_by(land_id=land.id).order_by(OwnershipHistory.transfer_date.desc()).first()
        days_since = (datetime.utcnow() - last_history.transfer_date).days if last_history else 365
        
        one_year_ago = datetime.utcnow() - timedelta(days=365)
        transfers_yr = OwnershipHistory.query.filter(OwnershipHistory.land_id == land.id, OwnershipHistory.transfer_date >= one_year_ago).count()
        
        doc_disc = 1 if Document.query.filter_by(land_id=land.id, verification_status='rejected').first() else 0
        
        prob, flags = detect_fraud(
            price_variance=price_var,
            days_since_last_transfer=days_since,
            num_transfers_last_year=transfers_yr,
            doc_discrepancy=doc_disc,
            model_path=fraud_model_path
        )
        
        doc = Document.query.filter_by(land_id=land.id).order_by(Document.uploaded_at.desc()).first()
        doc_status = doc.verification_status if doc else 'pending'
        
        pending_with_ai.append({
            'req': req,
            'land': land,
            'doc': doc,
            'doc_status': doc_status,
            'fraud_prob': int(prob * 100),
            'flags': flags
        })
        
    return render_template('pending_transfer_approvals.html', pending_items=pending_with_ai, pagination=pagination)

def pending_approvals():
    return pending_transfer_approvals()


@land_bp.route('/request/<int:request_id>/approve', methods=['POST'])
@login_required
def approve_request(request_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Revenue Officer / Registrar authority required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    req = LandRequest.query.get_or_404(request_id)
    if req.status == 'approved':
        flash('This transfer request has already been processed.', 'warning')
        return redirect(url_for('land.pending_transfer_approvals'))
        
    land = req.land
    
    # 1. Update Request Status for Online Transfer Approval ONLY (Land ownership remains with seller for required offline registration)
    req.status = 'approved'
    req.rejection_reason = None
    req.rejected_by = f"Approved by Revenue Officer ({current_user.username})"
    req.rejected_at = datetime.utcnow()
    
    # 2. Mark documents verified
    for doc in land.documents:
        if doc.verification_status == 'pending':
            doc.verification_status = 'approved'
            doc.verification_notes = f"Verified & Approved by Revenue Officer {current_user.username}"
            
    # 3. Notification ONLY to the Citizen who submitted this transfer request
    submitter_id = req.seller_id or req.buyer_id
    from models.notification import Notification
    existing_notif = Notification.query.filter_by(
        user_id=submitter_id,
        related_request_id=req.id,
        notification_type="land_transfer_approved"
    ).first()
    
    if not existing_notif:
        create_db_notification(
            user_id=submitter_id,
            title="🔔 Land Transfer Approved for Offline Registration",
            message="Your land transfer request has been approved for offline registration. Your Transfer Approval Certificate is now available.",
            notification_type="land_transfer_approved",
            related_request_id=req.id,
            related_land_id=land.id
        )
        
    db.session.commit()
    
    flash(f"TRANSFER REQUEST APPROVED! Transfer Approval Certificate generated for Land ({land.survey_number}). Reference: {req.transfer_ref}. The buyer and seller must visit the concerned Offline Registration Office to complete final registration.", 'success')
    return redirect(url_for('land.pending_transfer_approvals'))


@land_bp.route('/offline-registration-verification')
@land_bp.route('/offline-registration-verification/<int:selected_id>')
@login_required
def offline_registration_verification(selected_id=None):
    flash('Offline registration verification is now managed directly from Land Transfer Requests -> EDIT.', 'info')
    if selected_id:
        return redirect(url_for('land.edit_transfer_request', request_id=selected_id))
    return redirect(url_for('land.transfer_requests'))


@land_bp.route('/request/<int:request_id>/edit', methods=['GET', 'POST'])
@land_bp.route('/transfer-request/<int:request_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_transfer_request(request_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Revenue Officer authority required.', 'error')
        return redirect(url_for('land.transfer_requests'))
        
    req = db.session.get(LandRequest, request_id)
    if not req:
        flash(f'Transfer Request #{request_id} not found.', 'error')
        return redirect(url_for('land.transfer_requests'))

    if request.method == 'GET':
        current_date_iso = datetime.utcnow().strftime('%Y-%m-%d')
        return render_template('edit_transfer_request.html', req=req, current_date_iso=current_date_iso)

    # POST Submission: Save Draft or Submit & Complete Final Registration
    submit_action = request.form.get('submit_action', 'complete')
    existing_data = req.offline_data or {}
    seller_id_v = request.form.get('seller_id_verified') or existing_data.get('seller_id_verified')
    seller_sig_v = request.form.get('seller_sig_verified') or existing_data.get('seller_sig_verified')
    buyer_id_v = request.form.get('buyer_id_verified') or existing_data.get('buyer_id_verified')
    buyer_sig_v = request.form.get('buyer_sig_verified') or existing_data.get('buyer_sig_verified')
    doc_orig_v = request.form.get('doc_orig_verified') or existing_data.get('doc_orig_verified')
    doc_supp_v = request.form.get('doc_supp_verified') or existing_data.get('doc_supp_verified')

    seller_sig_file = request.files.get('seller_signature_file')
    buyer_sig_file = request.files.get('buyer_signature_file')
    offline_doc_file = request.files.get('offline_doc_file')

    seller_sig_path = existing_data.get('seller_sig_path')
    buyer_sig_path = existing_data.get('buyer_sig_path')
    offline_doc_path = existing_data.get('offline_doc_path')

    if seller_sig_file and seller_sig_file.filename != '':
        s_filename = f"seller_sig_{int(time.time())}_{secure_filename(seller_sig_file.filename)}"
        s_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], s_filename)
        seller_sig_file.save(s_save_path)
        seller_sig_path = f"static/uploads/{s_filename}"

    if buyer_sig_file and buyer_sig_file.filename != '':
        b_filename = f"buyer_sig_{int(time.time())}_{secure_filename(buyer_sig_file.filename)}"
        b_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], b_filename)
        buyer_sig_file.save(b_save_path)
        buyer_sig_path = f"static/uploads/{b_filename}"

    if offline_doc_file and offline_doc_file.filename != '':
        d_filename = f"offline_doc_{int(time.time())}_{secure_filename(offline_doc_file.filename)}"
        d_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], d_filename)
        offline_doc_file.save(d_save_path)
        offline_doc_path = f"static/uploads/{d_filename}"

    reg_office = request.form.get('registration_office', existing_data.get('office', 'Sub-Registrar Office, Central Zone'))
    reg_date = request.form.get('registration_date', existing_data.get('date', datetime.utcnow().strftime('%Y-%m-%d')))
    officer_name = request.form.get('officer_name', existing_data.get('officer_name', current_user.username))
    officer_id = request.form.get('officer_id', existing_data.get('officer_id', ''))
    remarks = request.form.get('verification_remarks', existing_data.get('remarks', ''))

    payload = {
        'office': reg_office,
        'date': reg_date,
        'officer_name': officer_name,
        'officer_id': officer_id,
        'remarks': remarks,
        'seller_sig_path': seller_sig_path,
        'buyer_sig_path': buyer_sig_path,
        'offline_doc_path': offline_doc_path,
        'seller_id_verified': bool(seller_id_v),
        'seller_sig_verified': bool(seller_sig_v),
        'buyer_id_verified': bool(buyer_id_v),
        'buyer_sig_verified': bool(buyer_sig_v),
        'doc_orig_verified': bool(doc_orig_v),
        'doc_supp_verified': bool(doc_supp_v),
        'updated_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    }

    if submit_action == 'save_draft':
        req.rejection_reason = json.dumps(payload)
        db.session.commit()
        flash(f'Draft saved successfully for Transfer Request {req.transfer_ref}.', 'success')
        return redirect(url_for('land.edit_transfer_request', request_id=req.id))

    # SUBMIT & COMPLETE FINAL REGISTRATION
    if not (seller_sig_v and buyer_sig_v and (doc_orig_v or doc_supp_v) and seller_sig_path and buyer_sig_path and offline_doc_path and reg_office and reg_date and officer_id):
        req.rejection_reason = json.dumps(payload)
        db.session.commit()
        flash('All required verification checks (Seller & Buyer signatures, Offline Documents, Registration Office & Officer ID) must be completed before final approval.', 'error')
        return redirect(url_for('land.edit_transfer_request', request_id=req.id))

    payload['completed_at'] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    req.status = 'completed'
    req.rejection_reason = json.dumps(payload)

    land = req.land
    old_owner_id = land.owner_id
    land.owner_id = req.buyer_id
    land.status = 'approved'

    existing_history = OwnershipHistory.query.filter_by(transfer_ref=req.transfer_ref).first()
    if not existing_history:
        history = OwnershipHistory(
            land_id=land.id,
            previous_owner_id=req.seller_id or old_owner_id,
            new_owner_id=req.buyer_id,
            transfer_price=req.bid_price or land.price,
            transfer_ref=req.transfer_ref
        )
        db.session.add(history)

    create_db_notification(
        user_id=req.buyer_id,
        title="🎉 Final Land Transfer Certificate Issued",
        message="Your land transfer has been successfully completed after offline verification. Your Final Transfer Certificate is now available.",
        notification_type="final_transfer_approved",
        related_request_id=req.id,
        related_land_id=land.id
    )

    if req.seller_id and req.seller_id != req.buyer_id:
        create_db_notification(
            user_id=req.seller_id,
            title="ℹ️ Property Title Ownership Transferred",
            message=f"Property Survey #{land.survey_number} transfer to {req.buyer.username if req.buyer else 'Buyer'} has been completed after official offline registration.",
            notification_type="final_transfer_approved",
            related_request_id=req.id,
            related_land_id=land.id
        )

    db.session.commit()
    flash(f'Transfer Request #{req.transfer_ref} has been successfully verified and completed!', 'success')
    return redirect(url_for('land.view_final_transfer_certificate', transfer_id=req.id))


@land_bp.route('/request/<int:request_id>/save-offline-verification', methods=['POST'])
@login_required
def save_offline_verification(request_id):
    return redirect(url_for('land.edit_transfer_request', request_id=request_id))


@land_bp.route('/request/<int:request_id>/complete-offline-verification', methods=['POST'])
@login_required
def complete_offline_verification(request_id):
    return redirect(url_for('land.edit_transfer_request', request_id=request_id))
        
    seller_id_v = request.form.get('seller_id_verified')
    seller_sig_v = request.form.get('seller_sig_verified')
    buyer_id_v = request.form.get('buyer_id_verified')
    buyer_sig_v = request.form.get('buyer_sig_verified')
    doc_orig_v = request.form.get('doc_orig_verified')
    doc_supp_v = request.form.get('doc_supp_verified')
    
    if not (seller_id_v and seller_sig_v and buyer_id_v and buyer_sig_v and doc_orig_v and doc_supp_v):
        flash('All required verification items (Seller/Buyer identity & signatures, Original & Supporting documents) must be completed before final approval.', 'error')
        return redirect(url_for('land.offline_registration_verification', selected_id=req.id))
        
    # Handle signature and document file uploads
    seller_sig_file = request.files.get('seller_signature_file')
    buyer_sig_file = request.files.get('buyer_signature_file')
    offline_doc_file = request.files.get('offline_doc_file')

    existing_data = req.offline_data or {}
    seller_sig_path = existing_data.get('seller_sig_path')
    buyer_sig_path = existing_data.get('buyer_sig_path')
    offline_doc_path = existing_data.get('offline_doc_path')

    if seller_sig_file and seller_sig_file.filename != '':
        s_filename = f"seller_sig_{int(time.time())}_{secure_filename(seller_sig_file.filename)}"
        s_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], s_filename)
        seller_sig_file.save(s_save_path)
        seller_sig_path = f"static/uploads/{s_filename}"

    if buyer_sig_file and buyer_sig_file.filename != '':
        b_filename = f"buyer_sig_{int(time.time())}_{secure_filename(buyer_sig_file.filename)}"
        b_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], b_filename)
        buyer_sig_file.save(b_save_path)
        buyer_sig_path = f"static/uploads/{b_filename}"

    if offline_doc_file and offline_doc_file.filename != '':
        d_filename = f"offline_doc_{int(time.time())}_{secure_filename(offline_doc_file.filename)}"
        d_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], d_filename)
        offline_doc_file.save(d_save_path)
        offline_doc_path = f"static/uploads/{d_filename}"

    reg_office = request.form.get('registration_office', '')
    reg_date = request.form.get('registration_date', '')
    officer_name = request.form.get('officer_name', current_user.username)
    officer_id = request.form.get('officer_id', '')
    remarks = request.form.get('verification_remarks', '')

    payload = {
        'office': reg_office,
        'date': reg_date,
        'officer_name': officer_name,
        'officer_id': officer_id,
        'remarks': remarks,
        'seller_sig_path': seller_sig_path,
        'buyer_sig_path': buyer_sig_path,
        'offline_doc_path': offline_doc_path,
        'seller_id_verified': bool(seller_id_v),
        'seller_sig_verified': bool(seller_sig_v),
        'buyer_id_verified': bool(buyer_id_v),
        'buyer_sig_verified': bool(buyer_sig_v),
        'doc_orig_verified': bool(doc_orig_v),
        'doc_supp_verified': bool(doc_supp_v),
        'completed_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    }
    req.status = 'completed'
    req.rejection_reason = json.dumps(payload)
    
    land = req.land
    old_owner_id = land.owner_id
    land.owner_id = req.buyer_id
    land.status = 'approved'
    
    history = OwnershipHistory(
        land_id=land.id,
        previous_owner_id=req.seller_id or old_owner_id,
        new_owner_id=req.buyer_id,
        transfer_price=req.bid_price or land.price,
        transfer_ref=req.transfer_ref
    )
    db.session.add(history)
    
    create_db_notification(
        user_id=req.buyer_id,
        title="🎉 Final Land Transfer Certificate Issued",
        message="Your land transfer has been successfully completed after offline verification. Your Final Transfer Certificate is now available.",
        notification_type="final_transfer_approved",
        related_request_id=req.id,
        related_land_id=land.id
    )
    
    if req.seller_id and req.seller_id != req.buyer_id:
        create_db_notification(
            user_id=req.seller_id,
            title="🎉 Final Land Transfer Completed",
            message="Your land transfer has been successfully completed after offline verification. Your Final Transfer Certificate is now available.",
            notification_type="final_transfer_approved",
            related_request_id=req.id,
            related_land_id=land.id
        )
        
    db.session.commit()
    
    flash(f"OFFLINE VERIFICATION COMPLETED & FINAL APPROVAL GRANTED! Property ownership of Survey #{land.survey_number} is now legally transferred to '{req.buyer.username}'. Final Transfer Certificate generated.", 'success')
    return redirect(url_for('land.view_final_transfer_certificate', transfer_id=req.id))



@land_bp.route('/request/<int:request_id>/reject', methods=['POST'])
@login_required
def reject_request(request_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Registrar authority required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    req = LandRequest.query.get_or_404(request_id)
    reason = request.form.get('rejection_reason', '').strip()
    if not reason:
        flash('Rejection reason is mandatory when rejecting a land transfer request.', 'error')
        return redirect(url_for('land.pending_transfer_approvals'))
    
    req.status = 'rejected'
    req.rejection_reason = reason
    req.rejected_by = f"Registrar ({current_user.username})"
    req.rejected_at = datetime.utcnow()
    req.land.status = 'verified'
    
    # Create Notifications for Buyer and Seller
    create_db_notification(
        user_id=req.buyer_id,
        title="🔔 Land Transfer Request Rejected",
        message="Your land transfer request has been rejected.",
        notification_type="land_transfer_rejected",
        related_request_id=req.id,
        related_land_id=req.land_id
    )
    
    if req.seller_id and req.seller_id != req.buyer_id:
        create_db_notification(
            user_id=req.seller_id,
            title="🔔 Land Transfer Request Rejected",
            message="Your land transfer request has been rejected.",
            notification_type="land_transfer_rejected",
            related_request_id=req.id,
            related_land_id=req.land_id
        )
        
    db.session.commit()
    flash(f"Transfer Request for {req.land.survey_number} has been Rejected. Reason: {reason}", 'warning')
    return redirect(url_for('land.pending_transfer_approvals'))


@land_bp.route('/api/notifications/mark-read/<int:notif_id>', methods=['POST'])
@login_required
def mark_notification_read(notif_id):
    from models.notification import Notification
    notif = Notification.query.filter_by(id=notif_id, user_id=current_user.id).first()
    if notif:
        notif.is_read = True
        db.session.commit()
        unread_count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
        return jsonify({'success': True, 'unread_count': unread_count})
    return jsonify({'success': False, 'message': 'Notification not found'}), 404


@land_bp.route('/api/notifications/mark-all-read', methods=['POST'])
@login_required
def mark_all_notifications_read():
    from models.notification import Notification
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({Notification.is_read: True})
    db.session.commit()
    return jsonify({'success': True, 'unread_count': 0})


@land_bp.route('/api/rejection-details/<type_str>/<int:item_id>')
@login_required
def rejection_details_api(type_str, item_id):
    if type_str == 'transfer':
        req = LandRequest.query.get_or_404(item_id)
        if current_user.role not in ['registrar', 'admin'] and current_user.id not in [req.buyer_id, req.seller_id]:
            return jsonify({'success': False, 'message': 'Access denied'}), 403
            
        rejected_by = req.rejected_by or 'Registrar'
        rejected_at_str = req.rejected_at.strftime('%d %b %Y, %I:%M %p') if req.rejected_at else (req.created_at.strftime('%d %b %Y, %I:%M %p') if req.created_at else 'N/A')
        return jsonify({
            'success': True,
            'request_id': f"TR-{'%04d' % req.id}",
            'survey_number': req.land.survey_number if req.land else 'N/A',
            'rejected_by': rejected_by,
            'rejected_date': rejected_at_str,
            'reason': req.rejection_reason or 'No specific reason provided.',
            'status': 'REJECTED'
        })
    elif type_str == 'officer':
        officer = User.query.get_or_404(item_id)
        if current_user.role != 'admin' and current_user.id != officer.id:
            return jsonify({'success': False, 'message': 'Access denied'}), 403
            
        rejected_by = getattr(officer, 'rejected_by', None) or 'Administrator'
        rej_at = getattr(officer, 'rejected_at', None)
        rejected_at_str = rej_at.strftime('%d %b %Y, %I:%M %p') if rej_at else (officer.created_at.strftime('%d %b %Y, %I:%M %p') if officer.created_at else 'N/A')
        return jsonify({
            'success': True,
            'request_id': officer.citizen_id or f"OFF-{'%04d' % officer.id}",
            'survey_number': f"Officer ID: {officer.citizen_id or officer.username}",
            'officer_name': officer.username,
            'officer_email': officer.email,
            'rejected_by': rejected_by,
            'rejected_date': rejected_at_str,
            'reason': officer.rejection_reason or 'Registration rejected during admin background check.',
            'status': 'REJECTED'
        })
    else:
        land = Land.query.get_or_404(item_id)
        if current_user.role not in ['registrar', 'admin'] and current_user.id != land.owner_id:
            return jsonify({'success': False, 'message': 'Access denied'}), 403
            
        rejected_by = land.rejected_by or 'Registrar'
        rejected_at_str = land.rejected_at.strftime('%d %b %Y, %I:%M %p') if land.rejected_at else (land.created_at.strftime('%d %b %Y, %I:%M %p') if land.created_at else 'N/A')
        return jsonify({
            'success': True,
            'request_id': f"REG-{'%04d' % land.id}",
            'survey_number': land.survey_number,
            'rejected_by': rejected_by,
            'rejected_date': rejected_at_str,
            'reason': land.rejection_reason or 'No specific reason provided.',
            'status': 'REJECTED'
        })


@land_bp.route('/api/officer-status/<int:user_id>')
@login_required
def officer_status_api(user_id):
    officer = User.query.get_or_404(user_id)
    if current_user.role != 'admin' and current_user.id != officer.id:
        return jsonify({'success': False, 'message': 'Access denied'}), 403

    rej_at = getattr(officer, 'rejected_at', None)
    rejected_at_str = rej_at.strftime('%d %b %Y, %I:%M %p') if rej_at else (officer.created_at.strftime('%d %b %Y, %I:%M %p') if officer.created_at else 'N/A')

    return jsonify({
        'success': True,
        'officer_id': officer.citizen_id or officer.username,
        'username': officer.username,
        'email': officer.email,
        'role': officer.role,
        'status': officer.status.upper() if officer.status else ('APPROVED' if officer.is_verified else 'PENDING'),
        'is_verified': officer.is_verified,
        'created_at': officer.created_at.strftime('%d %b %Y, %I:%M %p') if officer.created_at else 'N/A',
        'rejection_reason': officer.rejection_reason,
        'rejected_by': getattr(officer, 'rejected_by', 'Administrator') or 'Administrator',
        'rejected_date': rejected_at_str
    })


@land_bp.route('/api/pending-details/<type_str>/<int:item_id>')
@login_required
def pending_details_api(type_str, item_id):
    if type_str == 'transfer':
        req = LandRequest.query.get_or_404(item_id)
        if current_user.role not in ['registrar', 'admin'] and current_user.id not in [req.buyer_id, req.seller_id]:
            return jsonify({'success': False, 'message': 'Access denied'}), 403
            
        submitted_at_str = req.created_at.strftime('%d %b %Y, %I:%M %p') if req.created_at else 'N/A'
        return jsonify({
            'success': True,
            'request_id': f"TR-{'%04d' % req.id}",
            'survey_number': req.land.survey_number if req.land else 'N/A',
            'submitted_date': submitted_at_str,
            'status': 'PENDING APPROVAL',
            'message': 'Your land transfer request is pending approval.'
        })
    else:
        land = Land.query.get_or_404(item_id)
        if current_user.role not in ['registrar', 'admin'] and current_user.id != land.owner_id:
            return jsonify({'success': False, 'message': 'Access denied'}), 403
            
        submitted_at_str = land.created_at.strftime('%d %b %Y, %I:%M %p') if land.created_at else 'N/A'
        return jsonify({
            'success': True,
            'request_id': f"REG-{'%04d' % land.id}",
            'survey_number': land.survey_number,
            'submitted_date': submitted_at_str,
            'status': 'PENDING VERIFICATION',
            'message': 'Your land registration request is pending verification.'
        })


def generate_qr_code_base64(url):
    try:
        import qrcode
        import io
        import base64
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=4,
            border=2,
        )
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#1e3a8a", back_color="white")
        buffered = io.BytesIO()
        img.save(buffered)
        return base64.b64encode(buffered.getvalue()).decode('utf-8')
    except Exception as e:
        print(f"QR Code generation error: {e}")
        return ""


@land_bp.route('/verify-certificate/<cert_ref>')
def verify_certificate_page(cert_ref):
    if cert_ref.startswith('CERT-FIN-2026-'):
        try:
            val_id = int(cert_ref.replace('CERT-FIN-2026-', ''))
            req = LandRequest.query.get(val_id)
        except ValueError:
            req = None

        if req and req.status in ['completed', 'final_registered']:
            land = req.land
            return render_template(
                'certificates/verify_certificate.html',
                is_valid=True,
                land=land,
                cert_ref=cert_ref,
                registration_date=req.offline_registration_date,
                pid=land.pid or f"PID-KRN-{land.id:06d}",
                owner_name=req.buyer.username if req.buyer else 'N/A',
                owner_citizen_id=req.buyer_citizen_id or 'N/A',
                state=land.state or 'Telangana',
                district=land.city or 'Hyderabad',
                taluk='Central Taluk',
                hobli='Main Hobli',
                village=land.location or land.city,
                area_formatted=f"{land.area:,.2f} sq ft",
                land_type='Residential Plot' if land.area < 2000 else ('Commercial Plot' if land.price > 5000000 else 'Agricultural Land'),
                declared_value_formatted=f"₹{(req.bid_price or land.price):,.2f}"
            )
        else:
            return render_template(
                'certificates/verify_certificate.html',
                is_valid=False,
                cert_ref=cert_ref,
                message="Invalid or Unverified Final Certificate Reference. The specified land transfer record was not found or has not been completed after offline verification."
            )

    if cert_ref.startswith('CERT-TRF-2026-'):
        try:
            val_id = int(cert_ref.replace('CERT-TRF-2026-', ''))
            req = LandRequest.query.get(val_id)
            transfer = OwnershipHistory.query.get(val_id) if not req else None
        except ValueError:
            req = None
            transfer = None

        if req and req.status in ['approved', 'completed', 'final_registered']:
            if not transfer:
                transfer = OwnershipHistory.query.filter_by(land_id=req.land_id, new_owner_id=req.buyer_id).order_by(OwnershipHistory.id.desc()).first()
            if not transfer:
                transfer = OwnershipHistory.query.filter_by(land_id=req.land_id).order_by(OwnershipHistory.id.desc()).first()
            land = req.land
            transfer_date_str = transfer.transfer_date.strftime('%d %b %Y, %I:%M:%S %p UTC') if (transfer and transfer.transfer_date) else (req.created_at.strftime('%d %b %Y, %I:%M:%S %p UTC') if req.created_at else 'N/A')

            return render_template(
                'certificates/verify_certificate.html',
                is_valid=True,
                land=land,
                cert_ref=cert_ref,
                registration_date=transfer_date_str,
                pid=land.pid or f"PID-KRN-{land.id:06d}",
                owner_name=transfer.new_owner.username if (transfer and transfer.new_owner) else (req.buyer.username if req.buyer else 'N/A'),
                owner_citizen_id=transfer.new_owner.citizen_id if (transfer and transfer.new_owner) else (req.buyer_citizen_id or 'N/A'),
                state=land.state or 'Telangana',
                district=land.city or 'Hyderabad',
                taluk='Central Taluk',
                hobli='Main Hobli',
                village=land.location or land.city,
                area_formatted=f"{land.area:,.2f} sq ft",
                land_type='Residential Plot' if land.area < 2000 else ('Commercial Plot' if land.price > 5000000 else 'Agricultural Land'),
                declared_value_formatted=f"₹{transfer.transfer_price:,.2f}" if transfer else f"₹{land.price:,.2f}"
            )
        elif transfer:
            land = transfer.land
            transfer_date_str = transfer.transfer_date.strftime('%d %b %Y, %I:%M:%S %p UTC') if transfer.transfer_date else 'N/A'
            return render_template(
                'certificates/verify_certificate.html',
                is_valid=True,
                land=land,
                cert_ref=cert_ref,
                registration_date=transfer_date_str,
                pid=land.pid or f"PID-KRN-{land.id:06d}" if land else 'N/A',
                owner_name=transfer.new_owner.username if transfer.new_owner else 'N/A',
                owner_citizen_id=transfer.new_owner.citizen_id if transfer.new_owner else 'N/A',
                state=land.state or 'Telangana' if land else 'Karnataka',
                district=land.city or 'Hyderabad' if land else 'Bengaluru',
                taluk='Central Taluk',
                hobli='Main Hobli',
                village=(land.location or land.city) if land else 'Bengaluru',
                area_formatted=f"{land.area:,.2f} sq ft" if land else '1000.00 sq ft',
                land_type='Residential Plot' if land and land.area < 2000 else ('Commercial Plot' if land and land.price > 5000000 else 'Agricultural Land'),
                declared_value_formatted=f"₹{transfer.transfer_price:,.2f}"
            )
        else:
            return render_template(
                'certificates/verify_certificate.html',
                is_valid=False,
                cert_ref=cert_ref,
                message="Invalid or Unverified Transfer Certificate Reference. The specified land transfer record was not found or has not been approved by the Registrar."
            )

    land = None
    if cert_ref.startswith('CERT-REG-2026-'):
        try:
            land_id = int(cert_ref.replace('CERT-REG-2026-', ''))
            land = Land.query.get(land_id)
        except ValueError:
            pass
    elif cert_ref.isdigit():
        land = Land.query.get(int(cert_ref))
    else:
        land = Land.query.filter_by(survey_number=cert_ref).first()

    if not land or land.status not in ['verified', 'approved']:
        return render_template(
            'certificates/verify_certificate.html',
            is_valid=False,
            cert_ref=cert_ref,
            message="Invalid or Unverified Certificate Reference. The specified land record was not found or has not been officially approved by the Registrar."
        )

    history = OwnershipHistory.query.filter_by(land_id=land.id, previous_owner_id=None).first()
    approval_date = history.transfer_date if (history and history.transfer_date) else land.created_at
    registration_date_str = approval_date.strftime('%d %b %Y, %I:%M:%S %p UTC') if approval_date else 'N/A'

    return render_template(
        'certificates/verify_certificate.html',
        is_valid=True,
        land=land,
        cert_ref=land.certificate_reference,
        registration_date=registration_date_str,
        pid=land.pid or f"PID-KRN-{land.id:06d}",
        owner_name=land.owner.username if land.owner else 'N/A',
        owner_citizen_id=land.owner.citizen_id if land.owner else 'N/A',
        state=land.state or 'Telangana',
        district=land.city or 'Hyderabad',
        taluk='Central Taluk',
        hobli='Main Hobli',
        village=land.location or land.city,
        area_formatted=f"{land.area:,.2f} sq ft",
        land_type='Residential Plot' if land.area < 2000 else ('Commercial Plot' if land.price > 5000000 else 'Agricultural Land'),
        declared_value_formatted=f"₹{land.price:,.2f}"
    )


def _build_certificate_pdf(title_text, cert_ref, subtitle_text, fields_list, notice_text, filename, issued_date_str=None, qr_url=None):
    import io
    import qrcode
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.platypus import Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from flask import send_file

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    styles = getSampleStyleSheet()

    govt_style = ParagraphStyle('GovtStyle', parent=styles['Normal'], fontSize=9, leading=12, textColor=colors.HexColor('#475569'), alignment=1, fontName='Helvetica-Bold')
    title_style = ParagraphStyle('CertTitleStyle', parent=styles['Heading1'], fontSize=20, leading=24, textColor=colors.HexColor('#1e3a8a'), alignment=1, fontName='Helvetica-Bold')
    sub_style = ParagraphStyle('CertSubStyle', parent=styles['Normal'], fontSize=10, leading=13, textColor=colors.HexColor('#64748b'), alignment=1, fontName='Helvetica-Bold')

    label_style = ParagraphStyle('FieldLabel', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#64748b'), fontName='Helvetica-Bold')
    val_style = ParagraphStyle('FieldVal', parent=styles['Normal'], fontSize=10, leading=13, textColor=colors.HexColor('#0f172a'), fontName='Helvetica-Bold')

    story = []
    story.append(Paragraph("DEPARTMENT OF REVENUE & LAND RECORDS", govt_style))
    story.append(Spacer(1, 4))
    story.append(Paragraph(title_text, title_style))
    story.append(Paragraph(subtitle_text, sub_style))
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1e3a8a'), spaceBefore=4, spaceAfter=12))

    issued_dt = issued_date_str or datetime.utcnow().strftime('%d %b %Y, %I:%M %p')

    meta_table_data = [
        [
            Paragraph(f"<b>Certificate Ref:</b> <font color='#1e3a8a'>{cert_ref}</font>", label_style),
            Paragraph("<b>Status:</b> <font color='#15803d'>OFFICIALLY APPROVED</font>", label_style),
            Paragraph(f"<b>Issued Date:</b> {issued_dt}", label_style)
        ]
    ]
    meta_table = Table(meta_table_data, colWidths=[180, 180, 180])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8fafc')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#cbd5e1')),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 15))

    table_data = []
    for i in range(0, len(fields_list), 2):
        row = []
        lbl1, val1 = fields_list[i]
        row.append(Paragraph(lbl1, label_style))
        row.append(Paragraph(str(val1), val_style))
        if i + 1 < len(fields_list):
            lbl2, val2 = fields_list[i+1]
            row.append(Paragraph(lbl2, label_style))
            row.append(Paragraph(str(val2), val_style))
        else:
            row.append(Paragraph("", label_style))
            row.append(Paragraph("", val_style))
        table_data.append(row)

    grid_table = Table(table_data, colWidths=[110, 160, 110, 160])
    grid_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('LINEBELOW', (0,0), (-1,-1), 0.5, colors.HexColor('#e2e8f0')),
    ]))
    story.append(grid_table)
    story.append(Spacer(1, 15))

    notice_p = Paragraph(f"<b>Official Compliance Notice:</b> {notice_text}", ParagraphStyle('Notice', parent=styles['Normal'], fontSize=8.5, leading=12, textColor=colors.HexColor('#1e40af')))
    notice_table = Table([[notice_p]], colWidths=[540])
    notice_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#eff6ff')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#bfdbfe')),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(notice_table)
    story.append(Spacer(1, 20))

    qr_data = qr_url or cert_ref
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=3, border=1)
    qr.add_data(qr_data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="#1e3a8a", back_color="white")
    qr_buf = io.BytesIO()
    qr_img.save(qr_buf)
    qr_buf.seek(0)
    rl_qr = RLImage(qr_buf, width=65, height=65)

    seal_p = Paragraph(
        "<b>STATE LAND REGISTRY</b><br/>"
        "<font color='#1e3a8a'><b>OFFICIAL SEAL</b></font><br/>"
        "<font size=6 color='#64748b'>Dept. of Revenue</font>",
        ParagraphStyle('SealPdf', parent=styles['Normal'], fontSize=7.5, leading=10, alignment=1, textColor=colors.HexColor('#1e3a8a'))
    )

    qr_cell = [
        rl_qr,
        Spacer(1, 2),
        Paragraph(f"<font size=6 color='#475569'><b>{cert_ref}</b></font>", ParagraphStyle('QRPdf', parent=styles['Normal'], alignment=1))
    ]

    sig_p = Paragraph(
        "<font size=7 color='#059669'><b>Digitally Verified</b></font><br/>"
        "_______________________<br/>"
        "<b>Authorized Signature</b><br/>"
        "<b>District Registrar</b><br/>"
        "<font size=7 color='#64748b'>Department of Revenue & Land Records</font>",
        ParagraphStyle('SigPdf', parent=styles['Normal'], fontSize=8, leading=11, alignment=1, textColor=colors.HexColor('#0f172a'))
    )

    sig_data = [[seal_p, qr_cell, sig_p]]
    sig_table = Table(sig_data, colWidths=[180, 180, 180])
    sig_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(sig_table)

    doc.build(story)
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype='application/pdf'
    )


@land_bp.route('/certificate/registration/<int:land_id>')
@login_required
def view_land_certificate(land_id):
    land = Land.query.get_or_404(land_id)
    if land.status not in ['verified', 'approved']:
        flash("Certificate unavailable. Land registration is pending or has been rejected.", "error")
        return redirect(url_for('land.owned_lands'))

    if current_user.role == 'citizen' and land.owner_id != current_user.id:
        flash("Access denied. You are not authorized to view this certificate.", "error")
        return redirect(url_for('land.dashboard'))

    history = OwnershipHistory.query.filter_by(land_id=land.id, previous_owner_id=None).first()
    approval_date = history.transfer_date if (history and history.transfer_date) else land.created_at
    registration_date_str = approval_date.strftime('%d %b %Y, %I:%M:%S %p UTC') if approval_date else 'N/A'

    cert_ref = land.certificate_reference
    qr_url = url_for('land.verify_certificate_page', cert_ref=cert_ref, _external=True)
    qr_base64 = generate_qr_code_base64(qr_url)

    return render_template(
        'certificates/land_certificate.html',
        land=land,
        cert_ref=cert_ref,
        registration_date=registration_date_str,
        pid=land.pid or f"PID-KRN-{land.id:06d}",
        owner_name=land.owner.username if land.owner else 'N/A',
        owner_citizen_id=land.owner.citizen_id if land.owner else 'N/A',
        state=land.state or 'Telangana',
        district=land.city or 'Hyderabad',
        taluk='Central Taluk',
        hobli='Main Hobli',
        village=land.location or land.city,
        area_formatted=f"{land.area:,.2f} sq ft",
        land_type='Residential Plot' if land.area < 2000 else ('Commercial Plot' if land.price > 5000000 else 'Agricultural Land'),
        declared_value_formatted=f"₹{land.price:,.2f}",
        qr_url=qr_url,
        qr_base64=qr_base64
    )


@land_bp.route('/certificate/registration/<int:land_id>/download')
@login_required
def download_land_certificate(land_id):
    land = Land.query.get_or_404(land_id)
    if land.status not in ['verified', 'approved']:
        flash("Certificate unavailable. Land registration is pending or has been rejected.", "error")
        return redirect(url_for('land.owned_lands'))

    if current_user.role == 'citizen' and land.owner_id != current_user.id:
        flash("Access denied.", "error")
        return redirect(url_for('land.dashboard'))

    history = OwnershipHistory.query.filter_by(land_id=land.id, previous_owner_id=None).first()
    approval_date = history.transfer_date if (history and history.transfer_date) else land.created_at
    registration_date_str = approval_date.strftime('%d %b %Y, %I:%M:%S %p UTC') if approval_date else 'N/A'

    fields_list = [
        ("Survey Number", land.survey_number),
        ("Property PID", land.pid or f"PID-KRN-{land.id:06d}"),
        ("Owner Name", land.owner.username if land.owner else 'N/A'),
        ("Owner Citizen ID", land.owner.citizen_id if land.owner else 'N/A'),
        ("State", land.state or 'Telangana'),
        ("District", land.city or 'Hyderabad'),
        ("Taluk", 'Central Taluk'),
        ("Hobli", 'Main Hobli'),
        ("Village / Locality", land.location or land.city),
        ("Land Area", f"{land.area:,.2f} sq ft"),
        ("Land Type", 'Residential Plot' if land.area < 2000 else ('Commercial Plot' if land.price > 5000000 else 'Agricultural Land')),
        ("Declared Market Value", f"₹{land.price:,.2f}")
    ]

    cert_ref = land.certificate_reference
    qr_url = url_for('land.verify_certificate_page', cert_ref=cert_ref, _external=True)

    notice_text = f"This document certifies that Survey No. {land.survey_number} is registered in official State Land Records under ownership of {land.owner.username if land.owner else 'Citizen'}."
    filename = f"Land_Registration_Certificate_{land.survey_number}.pdf"
    
    return _build_certificate_pdf(
        title_text="Land Registration Certificate",
        cert_ref=cert_ref,
        subtitle_text="Official Title Deed & Property Ownership Record",
        fields_list=fields_list,
        notice_text=notice_text,
        filename=filename,
        issued_date_str=registration_date_str,
        qr_url=qr_url
    )


def _build_transfer_approval_pdf(req, qr_url=None):
    import io
    import qrcode
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.platypus import Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from flask import send_file

    land = req.land
    cert_ref = req.certificate_reference
    transfer_ref = req.transfer_ref

    seller_user = req.seller or land.owner
    seller_name = seller_user.username if seller_user else 'Current Owner'
    seller_citizen_id = req.seller_citizen_id or (seller_user.citizen_id if seller_user else 'N/A')

    buyer_user = req.buyer
    buyer_name = buyer_user.username if buyer_user else 'Proposed Buyer'
    buyer_citizen_id = req.buyer_citizen_id or (buyer_user.citizen_id if buyer_user else 'N/A')

    revenue_officer_name = getattr(req, 'approved_by', None) or 'Revenue Officer'
    revenue_officer_id = getattr(req, 'approved_officer_id', None) or 'RO-2026-001'

    approval_dt = getattr(req, 'approved_at', None) or req.created_at
    approval_date_str = approval_dt.strftime('%d %b %Y, %I:%M %p') if approval_dt else 'N/A'

    pid_str = land.pid or f"PID-KRN-{land.id:06d}"
    declared_val = req.bid_price or land.price
    declared_val_str = f"Rs. {declared_val:,.2f}"
    location_str = land.location or f"{land.city or ''}, {land.state or ''}".strip(', ')
    area_str = f"{land.area:,.2f} sq ft"

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    styles = getSampleStyleSheet()

    govt_style = ParagraphStyle('GovtHeader', parent=styles['Normal'], fontSize=9, leading=12, textColor=colors.HexColor('#475569'), alignment=1, fontName='Helvetica-Bold')
    title_style = ParagraphStyle('TitleHeader', parent=styles['Heading1'], fontSize=18, leading=22, textColor=colors.HexColor('#15803d'), alignment=1, fontName='Helvetica-Bold')
    sub_style = ParagraphStyle('SubHeader', parent=styles['Normal'], fontSize=10, leading=13, textColor=colors.HexColor('#64748b'), alignment=1, fontName='Helvetica-Bold')

    label_style = ParagraphStyle('FieldLabel', parent=styles['Normal'], fontSize=7.5, leading=10, textColor=colors.HexColor('#64748b'), fontName='Helvetica-Bold')
    val_style = ParagraphStyle('FieldVal', parent=styles['Normal'], fontSize=9.5, leading=12, textColor=colors.HexColor('#0f172a'), fontName='Helvetica-Bold')
    section_hdr_style = ParagraphStyle('SectionHeader', parent=styles['Normal'], fontSize=10, leading=13, textColor=colors.HexColor('#15803d'), fontName='Helvetica-Bold')

    story = []
    story.append(Paragraph("DEPARTMENT OF REVENUE & LAND RECORDS", govt_style))
    story.append(Spacer(1, 4))
    story.append(Paragraph("TRANSFER APPROVAL CERTIFICATE", title_style))
    story.append(Paragraph("For Offline Registration & Documentation", sub_style))
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#16a34a'), spaceBefore=2, spaceAfter=8))

    meta_table_data = [
        [
            Paragraph(f"<b>Certificate Ref:</b> <font color='#15803d'>{cert_ref}</font>", label_style),
            Paragraph("<b>Approval Status:</b> <font color='#15803d'>APPROVED FOR OFFLINE REGISTRATION</font>", label_style),
            Paragraph(f"<b>Approval Date:</b> {approval_date_str}", label_style)
        ]
    ]
    meta_table = Table(meta_table_data, colWidths=[180, 200, 160])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f0fdf4')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#bbf7d0')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 10))

    fields_list = [
        ("Transfer Approval Certificate Number", cert_ref),
        ("Transfer Reference Number", transfer_ref),
        ("Survey Number", land.survey_number),
        ("Property PID", pid_str),
        ("Current Owner / Seller Name", f"{seller_name} (ID: {seller_citizen_id})"),
        ("Proposed Buyer / New Owner Name", f"{buyer_name} (ID: {buyer_citizen_id})"),
        ("Transfer Reason", req.transfer_reason or 'Sale'),
        ("Property Location", location_str),
        ("Area", area_str),
        ("Declared Value", declared_val_str),
        ("Online Approval Date", approval_date_str),
        ("Approval Status", "APPROVED FOR OFFLINE REGISTRATION"),
        ("Revenue Officer Name", revenue_officer_name),
        ("Revenue Officer ID", revenue_officer_id),
        ("Department", "Department of Revenue & Land Records")
    ]

    table_data = []
    for i in range(0, len(fields_list), 2):
        row = []
        lbl1, val1 = fields_list[i]
        row.append(Paragraph(lbl1, label_style))
        row.append(Paragraph(str(val1), val_style))
        if i + 1 < len(fields_list):
            lbl2, val2 = fields_list[i+1]
            row.append(Paragraph(lbl2, label_style))
            row.append(Paragraph(str(val2), val_style))
        else:
            row.append(Paragraph("", label_style))
            row.append(Paragraph("", val_style))
        table_data.append(row)

    grid_table = Table(table_data, colWidths=[115, 155, 115, 155])
    grid_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('LINEBELOW', (0,0), (-1,-1), 0.5, colors.HexColor('#e2e8f0')),
    ]))
    story.append(grid_table)
    story.append(Spacer(1, 10))

    # Legal Statement
    legal_text = (
        "This certificate confirms only the online approval of the proposed land transfer. "
        "It does not constitute final legal registration or transfer of title. The buyer and seller must complete "
        "the required verification, signatures and official registration formalities at the concerned Offline Registration Office."
    )
    legal_p = Paragraph(legal_text, ParagraphStyle('LegalNotice', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#166534')))
    legal_table = Table([[legal_p]], colWidths=[540])
    legal_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f0fdf4')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#86efac')),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(legal_table)
    story.append(Spacer(1, 12))

    # OFFLINE REGISTRATION / DOCUMENTATION SECTION
    offline_hdr = Paragraph("<b>OFFLINE REGISTRATION / DOCUMENTATION</b>", section_hdr_style)
    story.append(offline_hdr)
    story.append(Spacer(1, 6))

    off_label = ParagraphStyle('OffLabel', parent=styles['Normal'], fontSize=8.5, leading=12, textColor=colors.HexColor('#334155'), fontName='Helvetica-Bold')

    offline_grid = [
        [
            Paragraph("Seller Signature: ______________________", off_label),
            Paragraph("Buyer Signature: ______________________", off_label)
        ],
        [
            Paragraph("Registering Officer Signature: ______________________", off_label),
            Paragraph("Office Seal: ______________________", off_label)
        ],
        [
            Paragraph("Registration Office: ______________________", off_label),
            Paragraph("Registration Date: ______________________", off_label)
        ]
    ]
    offline_table = Table(offline_grid, colWidths=[270, 270])
    offline_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8fafc')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#cbd5e1')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#e2e8f0')),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(offline_table)
    story.append(Spacer(1, 14))

    # QR Code & Signatures
    qr_data = qr_url or cert_ref
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=3, border=1)
    qr.add_data(qr_data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="#15803d", back_color="white")
    qr_buf = io.BytesIO()
    qr_img.save(qr_buf)
    qr_buf.seek(0)
    rl_qr = RLImage(qr_buf, width=60, height=60)

    seal_p = Paragraph(
        "<b>DEPARTMENT OF REVENUE & LAND RECORDS</b><br/>"
        "<font color='#15803d'><b>OFFICIAL REGISTRY SEAL</b></font><br/>"
        "<font size=6 color='#64748b'>Government Land Authority</font>",
        ParagraphStyle('SealPdf', parent=styles['Normal'], fontSize=7, leading=9, alignment=1, textColor=colors.HexColor('#15803d'))
    )

    qr_cell = [
        rl_qr,
        Spacer(1, 2),
        Paragraph(f"<font size=6 color='#475569'><b>{cert_ref}</b></font>", ParagraphStyle('QRPdf', parent=styles['Normal'], alignment=1))
    ]

    sig_p = Paragraph(
        f"<font size=7 color='#15803d'><b>Digitally Approved Online</b></font><br/>"
        f"<b>{revenue_officer_name}</b><br/>"
        f"<b>Revenue Officer (ID: {revenue_officer_id})</b><br/>"
        "<font size=7 color='#64748b'>Department of Revenue & Land Records</font>",
        ParagraphStyle('SigPdf', parent=styles['Normal'], fontSize=7.5, leading=10, alignment=1, textColor=colors.HexColor('#0f172a'))
    )

    sig_data = [[seal_p, qr_cell, sig_p]]
    sig_table = Table(sig_data, colWidths=[180, 180, 180])
    sig_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(sig_table)

    doc.build(story)
    buffer.seek(0)
    
    filename = f"Transfer_Approval_Certificate_{transfer_ref}.pdf"
    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype='application/pdf'
    )


@land_bp.route('/certificate/transfer/<int:transfer_id>')
@login_required
def view_transfer_certificate(transfer_id):
    req = LandRequest.query.get(transfer_id)
    if not req:
        req = LandRequest.query.filter_by(id=transfer_id).first()

    if not req or req.status not in ['approved', 'completed', 'final_registered']:
        flash("Certificate unavailable. Transfer Approval Certificate is only generated for APPROVED transfer requests.", "error")
        return redirect(url_for('land.transfer_requests'))

    land = req.land
    if not land:
        flash("Land record associated with this transfer request was not found.", "error")
        return redirect(url_for('land.transfer_requests'))

    allowed_users = [req.buyer_id, req.seller_id, land.owner_id]
    if current_user.role == 'citizen' and current_user.id not in [u for u in allowed_users if u is not None]:
        flash("Access denied. You are not authorized to view this certificate.", "error")
        return redirect(url_for('land.dashboard'))

    cert_ref = req.certificate_reference
    transfer_ref = req.transfer_ref
    qr_url = url_for('land.verify_certificate_page', cert_ref=cert_ref, _external=True)
    qr_base64 = generate_qr_code_base64(qr_url)

    approval_dt = getattr(req, 'approved_at', None) or req.created_at
    approval_date_str = approval_dt.strftime('%d %b %Y, %I:%M:%S %p UTC') if approval_dt else 'N/A'

    seller_user = req.seller or land.owner
    seller_name = seller_user.username if seller_user else 'Current Owner'
    seller_citizen_id = req.seller_citizen_id or (seller_user.citizen_id if seller_user else 'N/A')

    buyer_user = req.buyer
    buyer_name = buyer_user.username if buyer_user else 'Proposed Buyer'
    buyer_citizen_id = req.buyer_citizen_id or (buyer_user.citizen_id if buyer_user else 'N/A')

    revenue_officer_name = getattr(req, 'approved_by', None) or 'Revenue Officer'
    revenue_officer_id = getattr(req, 'approved_officer_id', None) or 'RO-2026-001'

    location_str = land.location or f"{land.city or ''}, {land.state or ''}".strip(', ')
    declared_val = req.bid_price or land.price

    return render_template(
        'certificates/transfer_certificate.html',
        req=req,
        land=land,
        cert_ref=cert_ref,
        transfer_ref=transfer_ref,
        approval_date=approval_date_str,
        approval_status='APPROVED FOR OFFLINE REGISTRATION',
        pid=land.pid or f"PID-KRN-{land.id:06d}",
        seller_name=seller_name,
        seller_citizen_id=seller_citizen_id,
        buyer_name=buyer_name,
        buyer_citizen_id=buyer_citizen_id,
        transfer_reason=req.transfer_reason or 'Sale',
        location=location_str,
        area_formatted=f"{land.area:,.2f} sq ft",
        declared_value_formatted=f"₹{declared_val:,.2f}",
        revenue_officer_name=revenue_officer_name,
        revenue_officer_id=revenue_officer_id,
        department='Department of Revenue & Land Records',
        qr_url=qr_url,
        qr_base64=qr_base64
    )


@land_bp.route('/certificate/transfer/<int:transfer_id>/download')
@login_required
def download_transfer_certificate(transfer_id):
    req = LandRequest.query.get(transfer_id)
    if not req:
        req = LandRequest.query.filter_by(id=transfer_id).first()

    if not req or req.status not in ['approved', 'completed', 'final_registered']:
        flash("Certificate unavailable. Transfer Approval Certificate is only generated for APPROVED transfer requests.", "error")
        return redirect(url_for('land.transfer_requests'))

    land = req.land
    if not land:
        flash("Land record associated with this transfer request was not found.", "error")
        return redirect(url_for('land.transfer_requests'))

    allowed_users = [req.buyer_id, req.seller_id, land.owner_id]
    if current_user.role == 'citizen' and current_user.id not in [u for u in allowed_users if u is not None]:
        flash("Access denied. You are not authorized to download this certificate.", "error")
        return redirect(url_for('land.dashboard'))

    cert_ref = req.certificate_reference
    qr_url = url_for('land.verify_certificate_page', cert_ref=cert_ref, _external=True)

    return _build_transfer_approval_pdf(req, qr_url=qr_url)


def _build_final_transfer_pdf(req, qr_url=None):
    import io
    import qrcode
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.platypus import Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from flask import send_file

    land = req.land
    final_cert_ref = req.final_certificate_reference
    transfer_ref = req.transfer_ref

    seller_user = req.seller
    seller_name = seller_user.username if seller_user else 'Previous Owner'
    seller_citizen_id = req.seller_citizen_id or (seller_user.citizen_id if seller_user else 'N/A')

    buyer_user = req.buyer
    buyer_name = buyer_user.username if buyer_user else 'New Owner'
    buyer_citizen_id = req.buyer_citizen_id or (buyer_user.citizen_id if buyer_user else 'N/A')

    online_approval_dt = getattr(req, 'approved_at', None) or req.created_at
    online_approval_date_str = online_approval_dt.strftime('%d %b %Y, %I:%M %p') if online_approval_dt else 'N/A'

    pid_str = land.pid or f"PID-KRN-{land.id:06d}"
    declared_val = req.bid_price or land.price
    declared_val_str = f"Rs. {declared_val:,.2f}"
    location_str = land.location or f"{land.city or ''}, {land.state or ''}".strip(', ')
    area_str = f"{land.area:,.2f} sq ft"

    off_office = req.registration_office
    off_date = req.offline_registration_date
    off_officer_name = req.registering_officer_name
    off_officer_id = req.registering_officer_id
    off_remarks = req.verification_remarks

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    styles = getSampleStyleSheet()

    govt_style = ParagraphStyle('GovtHeader', parent=styles['Normal'], fontSize=9, leading=12, textColor=colors.HexColor('#475569'), alignment=1, fontName='Helvetica-Bold')
    title_style = ParagraphStyle('TitleHeader', parent=styles['Heading1'], fontSize=18, leading=22, textColor=colors.HexColor('#15803d'), alignment=1, fontName='Helvetica-Bold')
    sub_style = ParagraphStyle('SubHeader', parent=styles['Normal'], fontSize=9.5, leading=13, textColor=colors.HexColor('#1e3a8a'), alignment=1, fontName='Helvetica-Bold')

    label_style = ParagraphStyle('FieldLabel', parent=styles['Normal'], fontSize=7.5, leading=10, textColor=colors.HexColor('#64748b'), fontName='Helvetica-Bold')
    val_style = ParagraphStyle('FieldVal', parent=styles['Normal'], fontSize=9.5, leading=12, textColor=colors.HexColor('#0f172a'), fontName='Helvetica-Bold')

    story = []
    story.append(Paragraph("DEPARTMENT OF REVENUE & LAND RECORDS", govt_style))
    story.append(Spacer(1, 4))
    story.append(Paragraph("FINAL TRANSFER CERTIFICATE", title_style))
    story.append(Paragraph("ORIGINAL TRANSFER CERTIFICATE — OFFICIAL TITLE DEED & COMPLETED OWNERSHIP RECORD", sub_style))
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=2.5, color=colors.HexColor('#15803d'), spaceBefore=2, spaceAfter=8))

    meta_table_data = [
        [
            Paragraph(f"<b>Final Cert Ref:</b> <font color='#15803d'>{final_cert_ref}</font>", label_style),
            Paragraph("<b>Final Status:</b> <font color='#15803d'>FINAL REGISTERED / TRANSFER COMPLETED</font>", label_style),
            Paragraph(f"<b>Final Reg Date:</b> {off_date}", label_style)
        ]
    ]
    meta_table = Table(meta_table_data, colWidths=[170, 220, 150])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f0fdf4')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#86efac')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 10))

    fields_list = [
        ("Final Certificate Number", final_cert_ref),
        ("Transfer Reference Number", transfer_ref),
        ("Survey Number", land.survey_number),
        ("Property PID", pid_str),
        ("Previous Owner / Seller Name", f"{seller_name} (ID: {seller_citizen_id})"),
        ("New Owner / Buyer Name", f"{buyer_name} (ID: {buyer_citizen_id})"),
        ("Transfer Reason", req.transfer_reason or 'Sale'),
        ("Property Location", location_str),
        ("Area", area_str),
        ("Declared Value", declared_val_str),
        ("Online Approval Date", online_approval_date_str),
        ("Offline Registration Date", off_date),
        ("Final Registration Date", off_date),
        ("Registration Office", off_office),
        ("Registering Officer Name", off_officer_name),
        ("Officer ID", off_officer_id),
        ("Final Status", "FINAL REGISTERED / TRANSFER COMPLETED"),
        ("Department", "Department of Revenue & Land Records")
    ]

    table_data = []
    for i in range(0, len(fields_list), 2):
        row = []
        lbl1, val1 = fields_list[i]
        row.append(Paragraph(lbl1, label_style))
        row.append(Paragraph(str(val1), val_style))
        if i + 1 < len(fields_list):
            lbl2, val2 = fields_list[i+1]
            row.append(Paragraph(lbl2, label_style))
            row.append(Paragraph(str(val2), val_style))
        else:
            row.append(Paragraph("", label_style))
            row.append(Paragraph("", val_style))
        table_data.append(row)

    grid_table = Table(table_data, colWidths=[115, 155, 115, 155])
    grid_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('LINEBELOW', (0,0), (-1,-1), 0.5, colors.HexColor('#e2e8f0')),
    ]))
    story.append(grid_table)
    story.append(Spacer(1, 10))

    audit_text = f"<b>Physical Verification Completed:</b> {off_remarks}"
    audit_p = Paragraph(audit_text, ParagraphStyle('AuditNotice', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#15803d')))
    audit_table = Table([[audit_p]], colWidths=[540])
    audit_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8fafc')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#cbd5e1')),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(audit_table)
    story.append(Spacer(1, 10))

    legal_text = (
        "This document certifies that the land transfer has been fully verified, executed, and legally registered "
        "following mandatory offline physical verification, document checks, and physical signature verifications. "
        "Title ownership is officially updated in the State Land Registry to the New Owner."
    )
    legal_p = Paragraph(legal_text, ParagraphStyle('LegalNotice', parent=styles['Normal'], fontSize=8, leading=11, textColor=colors.HexColor('#166534')))
    legal_table = Table([[legal_p]], colWidths=[540])
    legal_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f0fdf4')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#86efac')),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(legal_table)
    story.append(Spacer(1, 12))

    qr_data = qr_url or final_cert_ref
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=3, border=1)
    qr.add_data(qr_data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="#15803d", back_color="white")
    qr_buf = io.BytesIO()
    qr_img.save(qr_buf)
    qr_buf.seek(0)
    rl_qr = RLImage(qr_buf, width=60, height=60)

    seal_p = Paragraph(
        "<b>DEPARTMENT OF REVENUE & LAND RECORDS</b><br/>"
        "<font color='#15803d'><b>OFFICIAL REGISTRY SEAL</b></font><br/>"
        "<font size=6 color='#64748b'>Government Land Authority</font>",
        ParagraphStyle('SealPdf', parent=styles['Normal'], fontSize=7, leading=9, alignment=1, textColor=colors.HexColor('#15803d'))
    )

    qr_cell = [
        rl_qr,
        Spacer(1, 2),
        Paragraph(f"<font size=6 color='#475569'><b>{final_cert_ref}</b></font>", ParagraphStyle('QRPdf', parent=styles['Normal'], alignment=1))
    ]

    sig_p = Paragraph(
        f"<font size=7 color='#15803d'><b>Officially Signed & Approved</b></font><br/>"
        f"<b>{off_officer_name}</b><br/>"
        f"<b>Registering Officer (ID: {off_officer_id})</b><br/>"
        "<font size=7 color='#64748b'>Department of Revenue & Land Records</font>",
        ParagraphStyle('SigPdf', parent=styles['Normal'], fontSize=7.5, leading=10, alignment=1, textColor=colors.HexColor('#0f172a'))
    )

    sig_data = [[seal_p, qr_cell, sig_p]]
    sig_table = Table(sig_data, colWidths=[180, 180, 180])
    sig_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(sig_table)

    doc.build(story)
    buffer.seek(0)
    
    filename = f"Final_Transfer_Certificate_{transfer_ref}.pdf"
    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype='application/pdf'
    )


@land_bp.route('/certificate/final/<int:transfer_id>')
@login_required
def view_final_transfer_certificate(transfer_id):
    req = LandRequest.query.get(transfer_id)
    if not req:
        req = LandRequest.query.filter_by(id=transfer_id).first()

    if not req or req.status not in ['completed', 'final_registered']:
        flash("Final Transfer Certificate is unavailable. The final certificate is generated only after offline registration verification and final approval.", "error")
        return redirect(url_for('land.transfer_requests'))

    land = req.land
    if not land:
        flash("Land record associated with this transfer request was not found.", "error")
        return redirect(url_for('land.transfer_requests'))

    allowed_users = [req.buyer_id, req.seller_id, land.owner_id]
    if current_user.role == 'citizen' and current_user.id not in [u for u in allowed_users if u is not None]:
        flash("Access denied. You are not authorized to view this certificate.", "error")
        return redirect(url_for('land.dashboard'))

    final_cert_ref = req.final_certificate_reference
    transfer_ref = req.transfer_ref
    qr_url = url_for('land.verify_certificate_page', cert_ref=final_cert_ref, _external=True)
    qr_base64 = generate_qr_code_base64(qr_url)

    online_approval_dt = getattr(req, 'approved_at', None) or req.created_at
    online_approval_date_str = online_approval_dt.strftime('%d %b %Y, %I:%M:%S %p UTC') if online_approval_dt else 'N/A'

    seller_user = req.seller
    seller_name = seller_user.username if seller_user else 'Previous Owner'
    seller_citizen_id = req.seller_citizen_id or (seller_user.citizen_id if seller_user else 'N/A')

    buyer_user = req.buyer
    buyer_name = buyer_user.username if buyer_user else 'New Owner'
    buyer_citizen_id = req.buyer_citizen_id or (buyer_user.citizen_id if buyer_user else 'N/A')

    location_str = land.location or f"{land.city or ''}, {land.state or ''}".strip(', ')
    declared_val = req.bid_price or land.price

    return render_template(
        'certificates/final_transfer_certificate.html',
        req=req,
        land=land,
        final_cert_ref=final_cert_ref,
        transfer_ref=transfer_ref,
        online_approval_date=online_approval_date_str,
        offline_registration_date=req.offline_registration_date,
        final_registration_date=req.offline_registration_date,
        final_status='FINAL REGISTERED / TRANSFER COMPLETED',
        pid=land.pid or f"PID-KRN-{land.id:06d}",
        seller_name=seller_name,
        seller_citizen_id=seller_citizen_id,
        buyer_name=buyer_name,
        buyer_citizen_id=buyer_citizen_id,
        transfer_reason=req.transfer_reason or 'Sale',
        location=location_str,
        area_formatted=f"{land.area:,.2f} sq ft",
        declared_value_formatted=f"₹{declared_val:,.2f}",
        registration_office=req.registration_office,
        registering_officer_name=req.registering_officer_name,
        registering_officer_id=req.registering_officer_id,
        verification_remarks=req.verification_remarks,
        qr_url=qr_url,
        qr_base64=qr_base64
    )


@land_bp.route('/certificate/final/<int:transfer_id>/download')
@login_required
def download_final_transfer_certificate(transfer_id):
    req = LandRequest.query.get(transfer_id)
    if not req:
        req = LandRequest.query.filter_by(id=transfer_id).first()

    if not req or req.status not in ['completed', 'final_registered']:
        flash("Final Transfer Certificate is unavailable. The final certificate is generated only after offline registration verification and final approval.", "error")
        return redirect(url_for('land.transfer_requests'))

    land = req.land
    if not land:
        flash("Land record associated with this transfer request was not found.", "error")
        return redirect(url_for('land.transfer_requests'))

    allowed_users = [req.buyer_id, req.seller_id, land.owner_id]
    if current_user.role == 'citizen' and current_user.id not in [u for u in allowed_users if u is not None]:
        flash("Access denied. You are not authorized to download this certificate.", "error")
        return redirect(url_for('land.dashboard'))

    final_cert_ref = req.final_certificate_reference
    qr_url = url_for('land.verify_certificate_page', cert_ref=final_cert_ref, _external=True)

    return _build_final_transfer_pdf(req, qr_url=qr_url)



@land_bp.route('/api/property-details/<int:land_id>')
@login_required
def property_details_api(land_id):
    land = Land.query.get_or_404(land_id)
    risk_score, risk_level, _ = calculate_ownership_risk(land)
    
    city = land.city or (land.location.split(',')[0].strip() if land.location and ',' in land.location else land.location or 'Bengaluru')
    state = land.state or (land.location.split(',')[1].strip() if land.location and ',' in land.location else 'Karnataka')
    district = f"{city} District"
    taluk = f"{city} North Taluk"
    hobli = f"{city} Central Hobli"
    village = f"{city} Village Zone"
    address = land.location or f"Survey No. {land.survey_number}, {village}, {hobli}, {taluk}, {district}, {state}"

    docs = []
    if land.documents:
        for d in land.documents:
            docs.append({
                'id': d.id,
                'type': d.document_type.replace('_', ' ').title(),
                'file_path': d.file_path,
                'is_available': d.is_file_available,
                'status': d.verification_status,
                'notes': d.verification_notes or 'Deed document verified'
            })

    history_records = OwnershipHistory.query.filter_by(land_id=land.id).order_by(OwnershipHistory.transfer_date.asc()).all()
    history_list = []
    for h in history_records:
        history_list.append({
            'id': h.id,
            'transfer_ref': h.transfer_ref or f"REG-{h.id:04d}",
            'previous_owner': h.previous_owner.username if h.previous_owner else 'Initial Registry Grant',
            'previous_owner_cid': h.previous_owner.citizen_id if h.previous_owner else 'N/A',
            'new_owner': h.new_owner.username if h.new_owner else 'Registry Owner',
            'new_owner_cid': h.new_owner.citizen_id if h.new_owner else 'N/A',
            'transfer_price': h.transfer_price,
            'transfer_price_formatted': f"₹{h.transfer_price:,.2f}",
            'transfer_date': h.transfer_date.strftime('%d %b %Y, %I:%M %p') if h.transfer_date else 'N/A',
            'reason': 'Initial Title Grant' if not h.previous_owner else 'Property Ownership Transfer',
            'status': 'VERIFIED'
        })

    doc_status = 'Approved & Verified' if any(d.verification_status == 'approved' for d in land.documents) else ('Pending Audit' if land.documents else 'No Deed Uploaded')
    ocr_status = 'Tesseract OCR Passed' if any(d.verification_status == 'approved' for d in land.documents) else ('OCR Audit Pending' if land.documents else 'Unverified')

    return jsonify({
        'success': True,
        'id': land.id,
        'pid': land.pid or f"PID-KRN-{land.id:06d}",
        'survey_number': land.survey_number,
        'owner_name': land.owner.username if land.owner else 'Unknown',
        'owner_citizen_id': land.owner.citizen_id if land.owner else 'N/A',
        'area': land.area,
        'city': city,
        'state': state,
        'district': district,
        'taluk': taluk,
        'hobli': hobli,
        'village': village,
        'address': address,
        'property_type': 'Residential Plot' if land.area < 2000 else ('Commercial Plot' if land.price > 5000000 else 'Agricultural Land'),
        'declared_value': land.price,
        'declared_value_formatted': f"₹{land.price:,.2f}",
        'registration_date': land.created_at.strftime('%d %b %Y, %I:%M %p') if land.created_at else 'N/A',
        'status': (land.status or 'verified').upper(),
        'deed_status': doc_status,
        'ocr_status': ocr_status,
        'risk_score': int(risk_score * 100),
        'risk_level': risk_level,
        'documents': docs,
        'history': history_list
    })


@land_bp.route('/api/ownership-chain/<int:land_id>')
@login_required
def ownership_chain_api(land_id):
    land = Land.query.get_or_404(land_id)
    history = OwnershipHistory.query.filter_by(land_id=land.id).order_by(OwnershipHistory.transfer_date.asc()).all()
    
    chain = []
    for idx, h in enumerate(history, 1):
        chain.append({
            'step': idx,
            'ref': h.transfer_ref or f"REG-{h.id:04d}",
            'previous_owner': h.previous_owner.username if h.previous_owner else 'Initial Registration (Government Land Board)',
            'previous_owner_cid': h.previous_owner.citizen_id if h.previous_owner else 'N/A',
            'new_owner': h.new_owner.username if h.new_owner else 'Registry Owner',
            'new_owner_cid': h.new_owner.citizen_id if h.new_owner else 'N/A',
            'transfer_price': h.transfer_price,
            'transfer_price_formatted': f"₹{h.transfer_price:,.2f}",
            'transfer_date': h.transfer_date.strftime('%d %b %Y, %I:%M %p') if h.transfer_date else 'N/A',
            'reason': 'Initial Title Grant' if not h.previous_owner else 'Property Ownership Transfer',
            'status': 'VERIFIED & RECORDED'
        })
        
    return jsonify({
        'success': True,
        'land': {
            'id': land.id,
            'survey_number': land.survey_number,
            'pid': land.pid or f"PID-KRN-{land.id:06d}",
            'location': land.location or f"{land.city}, {land.state}",
            'owner_name': land.owner.username if land.owner else 'Unknown'
        },
        'chain': chain
    })


@land_bp.route('/api/transfer-details/<int:transfer_id>')
@login_required
def transfer_details_api(transfer_id):
    h = OwnershipHistory.query.get_or_404(transfer_id)
    land = h.land
    
    docs = []
    if land and land.documents:
        for d in land.documents:
            docs.append({
                'id': d.id,
                'type': d.document_type.replace('_', ' ').title(),
                'file_path': d.file_path,
                'is_available': d.is_file_available,
                'status': d.verification_status
            })
            
    req = LandRequest.query.filter_by(land_id=land.id, buyer_id=h.new_owner_id).order_by(LandRequest.id.desc()).first() if land else None
    submitted_date = req.created_at.strftime('%d %b %Y, %I:%M %p') if (req and req.created_at) else (h.transfer_date.strftime('%d %b %Y, %I:%M %p') if h.transfer_date else 'N/A')
    approval_date = h.transfer_date.strftime('%d %b %Y, %I:%M %p') if h.transfer_date else 'N/A'
    completion_date = h.transfer_date.strftime('%d %b %Y, %I:%M %p') if h.transfer_date else 'N/A'

    return jsonify({
        'success': True,
        'transfer_ref': h.transfer_ref or f"TR-{h.id:04d}",
        'survey_number': land.survey_number if land else 'N/A',
        'pid': (land.pid if land else None) or f"PID-KRN-{land.id:06d}" if land else 'N/A',
        'seller_name': h.previous_owner.username if h.previous_owner else 'Registry Initial Board',
        'seller_cid': h.previous_owner.citizen_id if h.previous_owner else 'N/A',
        'buyer_name': h.new_owner.username if h.new_owner else 'Registry Buyer',
        'buyer_cid': h.new_owner.citizen_id if h.new_owner else 'N/A',
        'transfer_reason': (req.transfer_reason if req else 'Property Ownership Sale'),
        'declared_price': h.transfer_price,
        'declared_price_formatted': f"₹{h.transfer_price:,.2f}",
        'submitted_date': submitted_date,
        'approval_date': approval_date,
        'completion_date': completion_date,
        'registrar_status': 'APPROVED & TRANSFERRED',
        'audit_status': 'VERIFIED IN MYSQL REGISTRY',
        'documents': docs
    })


@land_bp.route('/request/<int:request_id>/flag', methods=['POST'])
@login_required
def flag_request(request_id):
    if current_user.role != 'registrar':
        flash('Access denied. Registrar authority required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    req = LandRequest.query.get_or_404(request_id)
    req.status = 'flagged'
    req.land.status = 'flagged'
    
    db.session.commit()
    flash(f"Transfer Request for {req.land.survey_number} FLAGGED FOR REVIEW.", 'warning')
    return redirect(url_for('land.pending_transfer_approvals'))

@land_bp.route('/records')
@login_required
def records():
    page = request.args.get('page', 1, type=int)
    query = request.args.get('q', '').strip()
    
    if current_user.role in ['registrar', 'admin'] and query:
        clean_q = query.strip()
        search_survey = clean_q.lstrip('#').strip()
        
        all_lands = Land.query.all()
        exact_lands = [
            l for l in all_lands 
            if l.survey_number.lstrip('#').strip().lower() == search_survey.lower()
        ]
        
        if exact_lands:
            lands = exact_lands
        else:
            lands = Land.query.filter(
                (Land.survey_number.ilike(f"%{clean_q}%")) |
                (Land.survey_number.ilike(f"%{search_survey}%")) |
                (Land.pid.ilike(f"%{clean_q}%")) |
                (Land.city.ilike(f"%{clean_q}%"))
            ).all()

        land_ids = [l.id for l in lands]
        
        registration_records = lands
        current_ownership = lands
        
        transfer_requests = []
        if land_ids:
            transfer_requests = LandRequest.query.filter(
                LandRequest.land_id.in_(land_ids)
            ).order_by(LandRequest.created_at.desc()).all()
            
        pending_requests = [r for r in transfer_requests if r.status == 'pending']
        
        ownership_history = []
        if land_ids:
            ownership_history = OwnershipHistory.query.filter(
                OwnershipHistory.land_id.in_(land_ids)
            ).order_by(OwnershipHistory.transfer_date.asc()).all()
            
        transfer_history = transfer_requests
        
        documents = []
        if land_ids:
            documents = Document.query.filter(
                Document.land_id.in_(land_ids)
            ).all()

        display_survey = exact_lands[0].survey_number if exact_lands else (lands[0].survey_number if lands else clean_q)

        return render_template(
            'records.html',
            is_global_search=True,
            searched_survey_number=display_survey,
            search_query=query,
            registration_records=registration_records,
            current_ownership=current_ownership,
            transfer_requests=transfer_requests,
            pending_requests=pending_requests,
            ownership_history=ownership_history,
            transfer_history=transfer_history,
            documents=documents
        )

    if current_user.role == 'citizen':
        base_q = Land.query.filter(Land.owner_id == current_user.id)
    else:
        base_q = Land.query

    if query:
        base_q = base_q.filter(
            (Land.survey_number.ilike(f"%{query}%")) | 
            (Land.city.ilike(f"%{query}%")) | 
            (Land.pid.ilike(f"%{query}%"))
        )

    pagination = base_q.order_by(Land.id.desc()).paginate(page=page, per_page=20, error_out=False)
    lands = pagination.items

    land_ids = [l.id for l in lands]
    history_map = {}
    if land_ids:
        histories = OwnershipHistory.query.filter(OwnershipHistory.land_id.in_(land_ids)).order_by(OwnershipHistory.transfer_date.desc()).all()
        for h in histories:
            history_map.setdefault(h.land_id, []).append(h)

    records_with_history = [{'info': land, 'history': history_map.get(land.id, [])} for land in lands]

    return render_template('records.html', records=records_with_history, pagination=pagination, search_query=query)

@land_bp.route('/ownership-history')
@login_required
def ownership_history():
    page = request.args.get('page', 1, type=int)
    if current_user.role == 'citizen':
        pagination = OwnershipHistory.query.filter(
            (OwnershipHistory.previous_owner_id == current_user.id) |
            (OwnershipHistory.new_owner_id == current_user.id)
        ).order_by(OwnershipHistory.transfer_date.desc()).paginate(page=page, per_page=20, error_out=False)
    else:
        pagination = OwnershipHistory.query.order_by(OwnershipHistory.transfer_date.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('ownership_history.html', history_records=pagination.items, pagination=pagination)

@land_bp.route('/transfer-history')
@login_required
def transfer_history():
    page = request.args.get('page', 1, type=int)
    if current_user.role == 'citizen':
        pagination = OwnershipHistory.query.filter(
            OwnershipHistory.previous_owner_id.isnot(None),
            (OwnershipHistory.previous_owner_id == current_user.id) |
            (OwnershipHistory.new_owner_id == current_user.id)
        ).order_by(OwnershipHistory.transfer_date.desc()).paginate(page=page, per_page=20, error_out=False)
    else:
        pagination = OwnershipHistory.query.filter(OwnershipHistory.previous_owner_id.isnot(None)).order_by(OwnershipHistory.transfer_date.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('transfer_history.html', transfers=pagination.items, pagination=pagination)

# Legacy aliases for Marketplace & Payments to redirect cleanly
@land_bp.route('/gallery')
@login_required
def gallery():
    return redirect(url_for('land.transfer_requests'))

@land_bp.route('/requests')
@login_required
def requests_list():
    if current_user.role in ['registrar', 'admin']:
        return redirect(url_for('land.pending_approvals'))
    return redirect(url_for('land.transfer_requests'))

@land_bp.route('/payments')
@login_required
def payments_list():
    return redirect(url_for('land.transfer_requests'))


@land_bp.route('/profile')
@login_required
def profile():
    return render_template('profile.html')

@land_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    current_user.age = int(request.form.get('age', 0)) or None
    current_user.city = request.form.get('city')
    current_user.state = request.form.get('state')
    current_user.aadhar = request.form.get('aadhar')
    current_user.pan = request.form.get('pan')
    
    db.session.commit()
    flash('Profile details updated successfully!', 'success')
    return redirect(url_for('land.profile'))

@land_bp.route('/land/<int:land_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_land(land_id):
    if current_user.role not in ['citizen', 'admin']:
        flash('Access denied. Officers cannot edit land listings.', 'error')
        return redirect(url_for('admin.dashboard' if current_user.role == 'admin' else 'land.dashboard'))
    land = Land.query.get_or_404(land_id)
    if land.owner_id != current_user.id and current_user.role not in ['registrar', 'admin']:
        flash('Unauthorized to edit this property.', 'error')
        return redirect(url_for('land.dashboard'))
        
    if request.method == 'POST':
        area_str = request.form.get('area')
        city = request.form.get('city')
        state = request.form.get('state')
        price_str = request.form.get('price')
        pid = request.form.get('pid')
        survey_number = request.form.get('survey_number')
        
        land.area = float(area_str) if area_str else land.area
        land.city = city
        land.state = state
        land.location = f"{city}, {state}"
        land.price = float(price_str) if price_str else land.price
        land.pid = pid
        land.survey_number = survey_number
        
        land_image_file = request.files.get('land_image')
        aadhar_document_file = request.files.get('aadhar_document')
        
        if land_image_file and land_image_file.filename != '':
            img_filename = f"{int(time.time())}_{secure_filename(land_image_file.filename)}"
            img_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], img_filename)
            land_image_file.save(img_save_path)
            land.image_path = os.path.join('static', 'uploads', img_filename)
            
        if aadhar_document_file and aadhar_document_file.filename != '':
            doc_filename = f"{int(time.time())}_{secure_filename(aadhar_document_file.filename)}"
            doc_save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], doc_filename)
            aadhar_document_file.save(doc_save_path)
            land.aadhar_path = os.path.join('static', 'uploads', doc_filename)
            
            sha256_hash = hashlib.sha256()
            full_path = os.path.join(current_app.config['BASE_DIR'], land.aadhar_path)
            if os.path.exists(full_path):
                with open(full_path, "rb") as f:
                    for byte_block in iter(lambda: f.read(4096), b""):
                        sha256_hash.update(byte_block)
            file_hash = sha256_hash.hexdigest()
            
            is_valid, notes, discrepancy = verify_document_content(
                file_path=full_path,
                expected_survey_number=survey_number,
                expected_owner_name=current_user.username,
                expected_area=land.area
            )
            doc_status = 'approved' if is_valid else 'rejected'
            
            new_doc = Document(
                land_id=land.id,
                document_type='title_deed',
                file_path=land.aadhar_path,
                hash_value=file_hash,
                verification_status=doc_status,
                verification_notes=notes
            )
            db.session.add(new_doc)
            
        db.session.commit()
        flash('Property details updated successfully!', 'success')
        return redirect(url_for('land.owned_lands'))
        
    return render_template('edit_land.html', land=land)

@land_bp.route('/verification')
@login_required
def verification():
    page = request.args.get('page', 1, type=int)
    if current_user.role in ['registrar', 'admin']:
        pagination = Document.query.order_by(Document.uploaded_at.desc()).paginate(page=page, per_page=20, error_out=False)
        docs = pagination.items
    else:
        user_land_ids = [l[0] for l in db.session.query(Land.id).filter_by(owner_id=current_user.id).all()]
        if user_land_ids:
            pagination = Document.query.filter(Document.land_id.in_(user_land_ids)).order_by(Document.uploaded_at.desc()).paginate(page=page, per_page=20, error_out=False)
            docs = pagination.items
        else:
            pagination = None
            docs = []

        
    return render_template('verification.html', documents=docs, pagination=pagination)

@land_bp.route('/fraud-detection')
@login_required
def fraud_detection():
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. AI Fraud Detection is restricted to Officers.', 'error')
        return redirect(url_for('land.dashboard'))
        
    page = request.args.get('page', 1, type=int)
    dup_surveys = db.session.query(Land.survey_number).group_by(Land.survey_number).having(db.func.count(Land.id) > 1).limit(50).all()
    dup_survey_nums = [s[0] for s in dup_surveys]
    duplicates = Land.query.filter(Land.survey_number.in_(dup_survey_nums)).limit(50).all() if dup_survey_nums else []
    
    fake_docs = Document.query.filter_by(verification_status='rejected').limit(20).all()
    pagination = FraudRecord.query.order_by(FraudRecord.reported_at.desc()).paginate(page=page, per_page=20, error_out=False)
    
    return render_template(
        'fraud_detection.html',
        duplicates=duplicates,
        fake_docs=fake_docs,
        fraud_alerts=pagination.items,
        pagination=pagination
    )

