from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db
from models.fraud import FraudRecord
from models.land import Land
from models.document import Document
from models.prediction import PricePrediction
from models.ownership import OwnershipHistory

fraud_bp = Blueprint('fraud', __name__)

@fraud_bp.route('/fraud/alerts')
@login_required
def alerts_list():
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Registrar privileges required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    page = request.args.get('page', 1, type=int)
    pagination = FraudRecord.query.order_by(FraudRecord.reported_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('fraud_alerts.html', records=pagination.items, pagination=pagination)


@fraud_bp.route('/fraud/audit/<int:record_id>')
@login_required
def audit_details(record_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied. Registrar privileges required.', 'error')
        return redirect(url_for('land.dashboard'))
        
    record = FraudRecord.query.get_or_404(record_id)
    land = record.land
    if not land:
        flash('Associated land record not found.', 'error')
        return redirect(url_for('admin.dashboard'))
        
    doc = Document.query.filter_by(land_id=land.id).order_by(Document.uploaded_at.desc()).first()
    pred = PricePrediction.query.filter_by(land_id=land.id).order_by(PricePrediction.prediction_date.desc()).first()
    
    pred_price = pred.predicted_price if pred else land.price
    price_var = land.price / pred_price if pred_price > 0 else 1.0
    
    one_year_ago = datetime.utcnow() - timedelta(days=365)
    transfers_count = OwnershipHistory.query.filter(
        OwnershipHistory.land_id == land.id,
        OwnershipHistory.transfer_date >= one_year_ago
    ).count()
    
    risk_pct = int(record.risk_score * 100)
    if risk_pct >= 50:
        risk_level = 'HIGH RISK'
    elif risk_pct >= 25:
        risk_level = 'MEDIUM RISK'
    else:
        risk_level = 'LOW RISK'
        
    if doc:
        if doc.verification_status == 'approved':
            ocr_status = 'Verified'
        elif doc.verification_status == 'rejected':
            ocr_status = 'Failed'
        else:
            ocr_status = 'Pending'
        doc_notes = doc.verification_notes or 'OCR Hash check completed.'
    else:
        ocr_status = 'Pending'
        doc_notes = 'No physical document uploaded yet.'
        
    if record.status == 'resolved_clear':
        fraud_status = 'Cleared'
    elif record.status == 'confirmed_fraud':
        fraud_status = 'Flagged'
    else:
        fraud_status = 'Under Review'
        
    if risk_pct >= 50 or ocr_status == 'Failed':
        recommended_action = 'Manual Registrar Review Required'
    else:
        recommended_action = 'Routine Inspection Recommended'
        
    return render_template(
        'fraud_audit_details.html',
        record=record,
        land=land,
        doc=doc,
        prediction=pred,
        pred_price=pred_price,
        price_var=price_var,
        transfers_count=transfers_count,
        risk_score=risk_pct,
        risk_level=risk_level,
        ocr_status=ocr_status,
        doc_notes=doc_notes,
        fraud_status=fraud_status,
        recommended_action=recommended_action
    )


@fraud_bp.route('/fraud/resolve/<int:record_id>', methods=['POST'])
@login_required
def resolve_fraud(record_id):
    if current_user.role not in ['registrar', 'admin']:
        flash('Access denied.', 'error')
        return redirect(url_for('land.dashboard'))
        
    record = FraudRecord.query.get_or_404(record_id)
    resolution = request.form.get('resolution') # resolved_clear, confirmed_fraud
    notes = request.form.get('notes')
    
    record.status = resolution
    record.ai_feedback = f"{record.ai_feedback or ''}\n[Resolved as {resolution.upper()} by {current_user.username} on {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}] Notes: {notes}"
    
    land = Land.query.get(record.land_id)
    if land:
        if resolution == 'resolved_clear':
            # Check if there are other pending fraud alerts before marking verified
            other_active = FraudRecord.query.filter(
                FraudRecord.land_id == land.id, 
                FraudRecord.id != record.id,
                FraudRecord.status == 'investigating'
            ).first()
            if not other_active:
                land.status = 'verified'
        elif resolution == 'confirmed_fraud':
            land.status = 'flagged'
            
    db.session.commit()
    flash(f"Fraud audit successfully logged as {resolution.upper()}.", 'success')
    return redirect(url_for('admin.dashboard'))

