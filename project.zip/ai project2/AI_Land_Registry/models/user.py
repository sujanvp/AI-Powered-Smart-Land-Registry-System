from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

def generate_citizen_id():
    year = datetime.utcnow().strftime('%Y')
    prefix = f"CTZ-{year}-"
    last_user = User.query.filter(User.citizen_id.like(f"{prefix}%")).order_by(User.id.desc()).first()
    if last_user and last_user.citizen_id:
        try:
            seq = int(last_user.citizen_id.split('-')[-1]) + 1
        except ValueError:
            seq = User.query.count() + 1
    else:
        seq = User.query.count() + 1
    return f"CTZ-{year}-{seq:04d}"

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    citizen_id = db.Column(db.String(20), unique=True, nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='citizen') # citizen, registrar, admin
    
    # Profile Fields
    age = db.Column(db.Integer, nullable=True)
    city = db.Column(db.String(80), nullable=True)
    state = db.Column(db.String(80), nullable=True)
    aadhar = db.Column(db.String(20), nullable=True)
    pan = db.Column(db.String(20), nullable=True)
    is_verified = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(20), default='approved') # pending, approved, rejected
    rejection_reason = db.Column(db.Text, nullable=True)
    rejected_by = db.Column(db.String(80), nullable=True)
    rejected_at = db.Column(db.DateTime, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    lands = db.relationship('Land', backref='owner', lazy=True, foreign_keys='Land.owner_id')
    
    def __init__(self, username, email, role='citizen', age=None, city=None, state=None, aadhar=None, pan=None, is_verified=True, citizen_id=None, status='approved', rejection_reason=None):
        self.username = username
        self.email = email
        self.role = role
        self.age = age
        self.city = city
        self.state = state
        self.aadhar = aadhar
        self.pan = pan
        self.is_verified = is_verified
        self.status = status if status else ('approved' if is_verified else 'pending')
        self.rejection_reason = rejection_reason
        self.citizen_id = citizen_id if citizen_id else generate_citizen_id()


    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
        
    def __repr__(self):
        return f'<User {self.username} ({self.citizen_id} - {self.role})>'
