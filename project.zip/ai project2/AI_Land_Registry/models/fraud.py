from datetime import datetime
import json
try:
    from . import db
except ImportError:
    from models import db

class FraudRecord(db.Model):
    __tablename__ = 'fraud_records'
    
    id = db.Column(db.Integer, primary_key=True)
    land_id = db.Column(db.Integer, db.ForeignKey('lands.id'), nullable=False)
    risk_score = db.Column(db.Float, nullable=False, default=0.0) # 0.0 to 1.0
    _fraud_flags = db.Column(db.Text, nullable=True) # Stored as JSON string
    status = db.Column(db.String(20), nullable=False, default='investigating') # investigating, resolved_clear, confirmed_fraud
    ai_feedback = db.Column(db.Text, nullable=True)
    reported_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, land_id, risk_score=0.0, status='investigating', ai_feedback=None, fraud_flags=None):
        self.land_id = land_id
        self.risk_score = risk_score
        self.status = status
        self.ai_feedback = ai_feedback
        if fraud_flags is not None:
            self.fraud_flags = fraud_flags

    @property
    def fraud_flags(self):
        if not self._fraud_flags:
            return []
        try:
            return json.loads(self._fraud_flags)
        except Exception:
            return []
            
    @fraud_flags.setter
    def fraud_flags(self, value):
        if value is None:
            self._fraud_flags = None
        else:
            self._fraud_flags = json.dumps(value)

    def __repr__(self):
        return f'<FraudRecord Land {self.land_id} Risk {self.risk_score}>'
