from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

class Document(db.Model):
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    land_id = db.Column(db.Integer, db.ForeignKey('lands.id'), nullable=False)
    document_type = db.Column(db.String(50), nullable=False) # title_deed, tax_receipt, survey_map
    file_path = db.Column(db.String(255), nullable=False)
    hash_value = db.Column(db.String(64), nullable=False) # SHA-256 hash
    verification_status = db.Column(db.String(20), nullable=False, default='pending') # pending, approved, rejected
    verification_notes = db.Column(db.Text, nullable=True)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, land_id, document_type, file_path, hash_value, verification_status='pending', verification_notes=None):
        self.land_id = land_id
        self.document_type = document_type
        self.file_path = file_path
        self.hash_value = hash_value
        self.verification_status = verification_status
        self.verification_notes = verification_notes

    @property
    def is_file_available(self):
        if not self.file_path:
            return False
        import os
        from flask import current_app
        clean_path = self.file_path.replace('\\', '/').lstrip('/')
        if '..' in clean_path:
            return False
        if clean_path.startswith('static/'):
            clean_no_static = clean_path[7:].lstrip('/')
        else:
            clean_no_static = clean_path
        filename = os.path.basename(clean_path)
        try:
            upload_folder = current_app.config['UPLOAD_FOLDER']
            base_dir = current_app.config['BASE_DIR']
            candidates = [
                os.path.join(upload_folder, filename),
                os.path.join(base_dir, clean_path),
                os.path.join(base_dir, 'static', clean_no_static),
                os.path.join(upload_folder, clean_no_static)
            ]
            return any(os.path.exists(c) and os.path.isfile(c) for c in candidates)
        except Exception:
            return False

    def __repr__(self):
        return f'<Document {self.document_type} - Land {self.land_id}>'
