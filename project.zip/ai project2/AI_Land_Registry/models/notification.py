from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    notification_type = db.Column(db.String(50), nullable=False, default='info')
    # Types: land_registration_approved, land_registration_rejected, land_transfer_approved, land_transfer_rejected, doc_verification_failed, fraud_risk_detected, pending_review
    related_request_id = db.Column(db.Integer, nullable=True)
    related_land_id = db.Column(db.Integer, nullable=True)
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('notifications', lazy=True, cascade="all, delete-orphan"))
    
    def __init__(self, user_id, title, message, notification_type='info', related_request_id=None, related_land_id=None, is_read=False):
        self.user_id = user_id
        self.title = title
        self.message = message
        self.notification_type = notification_type
        self.related_request_id = related_request_id
        self.related_land_id = related_land_id
        self.is_read = is_read

    def __repr__(self):
        return f'<Notification {self.id} - User {self.user_id} - {self.title}>'
