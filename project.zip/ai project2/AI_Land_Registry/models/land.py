from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

class Land(db.Model):
    __tablename__ = 'lands'
    
    id = db.Column(db.Integer, primary_key=True)
    survey_number = db.Column(db.String(50), unique=True, nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    area = db.Column(db.Float, nullable=False) # In sq ft/sqm
    location = db.Column(db.String(100), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending') # pending, verified, flagged, for_sale
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    # Extended Form Fields matching Screenshot 1
    pid = db.Column(db.String(50), nullable=True)
    city = db.Column(db.String(80), nullable=True)
    state = db.Column(db.String(80), nullable=True)
    image_path = db.Column(db.String(255), nullable=True)
    aadhar_path = db.Column(db.String(255), nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)
    rejected_by = db.Column(db.String(80), nullable=True)
    rejected_at = db.Column(db.DateTime, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    documents = db.relationship('Document', backref='land', lazy=True, cascade="all, delete-orphan")
    ownership_history = db.relationship('OwnershipHistory', backref='land', lazy=True, cascade="all, delete-orphan", foreign_keys='OwnershipHistory.land_id')
    fraud_records = db.relationship('FraudRecord', backref='land', lazy=True, cascade="all, delete-orphan")
    predictions = db.relationship('PricePrediction', backref='land', lazy=True, cascade="all, delete-orphan")
    
    def __init__(self, survey_number, owner_id, area, location, latitude, longitude, price, status='pending', description=None, pid=None, city=None, state=None, image_path=None, aadhar_path=None):
        self.survey_number = survey_number
        self.owner_id = owner_id
        self.area = area
        self.location = location
        self.latitude = latitude
        self.longitude = longitude
        self.price = price
        self.status = status
        self.description = description
        self.pid = pid
        self.city = city
        self.state = state
        self.image_path = image_path
        self.aadhar_path = aadhar_path

    @property
    def certificate_reference(self):
        return f"CERT-REG-2026-{self.id:06d}"

    def __repr__(self):
        return f'<Land {self.survey_number}>'
