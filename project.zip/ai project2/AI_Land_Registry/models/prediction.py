from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

class PricePrediction(db.Model):
    __tablename__ = 'price_predictions'
    
    id = db.Column(db.Integer, primary_key=True)
    land_id = db.Column(db.Integer, db.ForeignKey('lands.id'), nullable=False)
    predicted_price = db.Column(db.Float, nullable=False)
    low_estimate = db.Column(db.Float, nullable=False)
    high_estimate = db.Column(db.Float, nullable=False)
    confidence_score = db.Column(db.Float, nullable=False) # R2 score or relative confidence
    prediction_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, land_id, predicted_price, low_estimate, high_estimate, confidence_score):
        self.land_id = land_id
        self.predicted_price = predicted_price
        self.low_estimate = low_estimate
        self.high_estimate = high_estimate
        self.confidence_score = confidence_score

    def __repr__(self):
        return f'<PricePrediction Land {self.land_id} Predicted {self.predicted_price}>'
