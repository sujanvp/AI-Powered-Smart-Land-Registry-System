from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

class OwnershipHistory(db.Model):
    __tablename__ = 'ownership_history'
    
    id = db.Column(db.Integer, primary_key=True)
    land_id = db.Column(db.Integer, db.ForeignKey('lands.id'), nullable=False)
    previous_owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True) # Null for initial registration
    new_owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    transfer_date = db.Column(db.DateTime, default=datetime.utcnow)
    transfer_price = db.Column(db.Float, nullable=False)
    transfer_ref = db.Column(db.String(64), nullable=False, unique=True) # Reference e.g. REC-20260729-1001
    
    # Relationships to User
    previous_owner = db.relationship('User', foreign_keys=[previous_owner_id], backref='transfers_sent')
    new_owner = db.relationship('User', foreign_keys=[new_owner_id], backref='transfers_received')
    
    def __init__(self, land_id, previous_owner_id, new_owner_id, transfer_price, transfer_ref):
        self.land_id = land_id
        self.previous_owner_id = previous_owner_id
        self.new_owner_id = new_owner_id
        self.transfer_price = transfer_price
        self.transfer_ref = transfer_ref

    def __repr__(self):
        return f'<OwnershipHistory Land {self.land_id} -> {self.transfer_ref}>'
