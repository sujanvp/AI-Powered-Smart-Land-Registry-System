from datetime import datetime
try:
    from . import db
except ImportError:
    from models import db

class LandRequest(db.Model):
    __tablename__ = 'land_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    land_id = db.Column(db.Integer, db.ForeignKey('lands.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    seller_citizen_id = db.Column(db.String(20), nullable=True)
    buyer_citizen_id = db.Column(db.String(20), nullable=True)
    bid_price = db.Column(db.Float, nullable=True, default=0.0)
    transfer_reason = db.Column(db.String(50), nullable=True, default='Sale') # Sale, Gift, Inheritance
    transfer_doc_path = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='pending') # pending, approved, rejected
    rejection_reason = db.Column(db.Text, nullable=True)
    rejected_by = db.Column(db.String(80), nullable=True)
    rejected_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    land = db.relationship('Land', backref=db.backref('requests', lazy=True, cascade="all, delete-orphan"))
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref=db.backref('land_requests', lazy=True))
    seller = db.relationship('User', foreign_keys=[seller_id], backref=db.backref('land_transfer_sales', lazy=True))
    
    def __init__(self, land_id, buyer_id, seller_id=None, seller_citizen_id=None, buyer_citizen_id=None, bid_price=0.0, transfer_reason='Sale', transfer_doc_path=None, status='pending', rejection_reason=None):
        self.land_id = land_id
        self.buyer_id = buyer_id
        self.seller_id = seller_id
        self.seller_citizen_id = seller_citizen_id
        self.buyer_citizen_id = buyer_citizen_id
        self.bid_price = bid_price
        self.transfer_reason = transfer_reason
        self.transfer_doc_path = transfer_doc_path
        self.status = status
        self.rejection_reason = rejection_reason

    @property
    def certificate_reference(self):
        return f"CERT-TRF-2026-{self.id:06d}"

    @property
    def final_certificate_reference(self):
        return f"CERT-FIN-2026-{self.id:06d}"

    @property
    def transfer_ref(self):
        year = self.created_at.year if self.created_at else 2026
        return f"TRF-{year}-{self.id:04d}"

    @property
    def approved_by(self):
        if self.rejected_by and 'Approved by' in self.rejected_by:
            val = self.rejected_by.replace('Approved by Revenue Officer (', '').rstrip(')').replace('Approved by ', '')
            return val if val else 'Revenue Officer'
        return 'Revenue Officer'

    @property
    def approved_officer_id(self):
        return 'RO-2026-001'

    @property
    def approved_at(self):
        return self.rejected_at or self.created_at

    @property
    def offline_data(self):
        if self.rejection_reason:
            try:
                import json
                if isinstance(self.rejection_reason, str) and self.rejection_reason.strip().startswith('{'):
                    return json.loads(self.rejection_reason)
            except Exception:
                pass
        return {}

    @property
    def registration_office(self):
        return self.offline_data.get('office', 'Sub-Registrar Office, Central Zone')

    @property
    def offline_registration_date(self):
        return self.offline_data.get('date', self.created_at.strftime('%Y-%m-%d') if self.created_at else '2026-09-10')

    @property
    def registering_officer_name(self):
        return self.offline_data.get('officer_name', self.approved_by)

    @property
    def registering_officer_id(self):
        return self.offline_data.get('officer_id', 'RO-2026-001')

    @property
    def verification_remarks(self):
        return self.offline_data.get('remarks', 'All physical signatures and original documents verified at Offline Registration Office.')

    @property
    def seller_signature_path(self):
        return self.offline_data.get('seller_sig_path')

    @property
    def buyer_signature_path(self):
        return self.offline_data.get('buyer_sig_path')

    @property
    def offline_document_path(self):
        return self.offline_data.get('offline_doc_path')

    def __repr__(self):
        return f'<LandRequest {self.id} - Land {self.land_id} - Seller {self.seller_citizen_id} -> Buyer {self.buyer_citizen_id} ({self.transfer_reason})>'



