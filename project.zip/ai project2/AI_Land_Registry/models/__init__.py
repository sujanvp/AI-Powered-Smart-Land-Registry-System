from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import models so they register with the SQLAlchemy metadata
from .user import User
from .land import Land
from .document import Document
from .ownership import OwnershipHistory
from .fraud import FraudRecord
from .prediction import PricePrediction
from .request import LandRequest
from .notification import Notification
