import os
import pandas as pd
import numpy as np

# Locations and their average price per sq ft and base coordinate centers
LOCATIONS = {
    'Downtown': {'rate': 550, 'lat': 12.9716, 'lon': 77.5946},
    'Uptown': {'rate': 380, 'lat': 13.0300, 'lon': 77.5600},
    'Suburbs': {'rate': 220, 'lat': 12.9100, 'lon': 77.6400},
    'Industrial': {'rate': 160, 'lat': 12.8500, 'lon': 77.6800},
    'Rural': {'rate': 60, 'lat': 13.1500, 'lon': 77.4500}
}

def generate_synthetic_data(filepath, n_samples=1000):
    np.random.seed(42)
    
    data = []
    for _ in range(n_samples):
        location = np.random.choice(list(LOCATIONS.keys()))
        loc_info = LOCATIONS[location]
        
        # Area in sq ft (between 500 and 10000)
        area = np.random.randint(500, 10000)
        
        # Add slight random noise to coordinates
        lat = loc_info['lat'] + np.random.normal(0, 0.01)
        lon = loc_info['lon'] + np.random.normal(0, 0.01)
        
        # Calculate fair market value (price) with some noise
        base_rate = loc_info['rate']
        fair_price = area * base_rate * np.random.uniform(0.9, 1.1)
        
        # Transaction price: can be fair, or heavily inflated/deflated (fraud)
        fraud_type = np.random.choice(['none', 'price_anomaly', 'rapid_flipping', 'document_forgery'], p=[0.85, 0.05, 0.05, 0.05])
        
        price_variance = 1.0
        days_since_last_transfer = np.random.randint(100, 2000)
        num_transfers_last_year = np.random.choice([0, 1], p=[0.9, 0.1])
        doc_discrepancy = 0
        is_fraud = 0
        
        if fraud_type == 'price_anomaly':
            # Price is either extremely cheap (undervalued to avoid tax or scam) or extremely expensive (money laundering)
            price_variance = np.random.choice([0.3, 2.5])
            is_fraud = 1
        elif fraud_type == 'rapid_flipping':
            days_since_last_transfer = np.random.randint(2, 30)
            num_transfers_last_year = np.random.randint(3, 6)
            is_fraud = 1
        elif fraud_type == 'document_forgery':
            doc_discrepancy = 1
            is_fraud = 1
            
        transaction_price = fair_price * price_variance
        
        data.append({
            'location': location,
            'area': area,
            'latitude': lat,
            'longitude': lon,
            'fair_price': fair_price,
            'transaction_price': transaction_price,
            'price_variance': price_variance,
            'days_since_last_transfer': days_since_last_transfer,
            'num_transfers_last_year': num_transfers_last_year,
            'doc_discrepancy': doc_discrepancy,
            'is_fraud': is_fraud
        })
        
    df = pd.DataFrame(data)
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    df.to_csv(filepath, index=False)
    print(f"Dataset generated at {filepath} with {n_samples} samples.")

if __name__ == '__main__':
    # Determine local directory path
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    target_path = os.path.join(base_dir, 'dataset', 'land_transactions.csv')
    generate_synthetic_data(target_path)
