import os
import socket

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'super-secret-key-for-ai-smart-land-registry'
    
    # Base directory
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    
    # MySQL Database Parameters
    MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', '')
    MYSQL_HOST = os.environ.get('MYSQL_HOST', 'localhost')
    MYSQL_DB = os.environ.get('MYSQL_DB', 'land_registry_db')
    
    MYSQL_DATABASE_URI = f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"
    SQLITE_DATABASE_URI = 'sqlite:///' + os.path.join(BASE_DIR, 'land_registry.db')
    
    # Database Selection: Use DATABASE_URL if set, or test if MySQL server is active on host:3306, else SQLite fallback
    if os.environ.get('DATABASE_URL'):
        SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    else:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1.0)
            connection_status = sock.connect_ex((MYSQL_HOST, 3306))
            sock.close()
            
            if connection_status == 0:
                SQLALCHEMY_DATABASE_URI = MYSQL_DATABASE_URI
            else:
                SQLALCHEMY_DATABASE_URI = SQLITE_DATABASE_URI
        except Exception:
            SQLALCHEMY_DATABASE_URI = SQLITE_DATABASE_URI

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # File Uploads
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'txt'}
    
    # ML Models & Dataset
    ML_MODEL_FOLDER = os.path.join(BASE_DIR, 'ml', 'models')
    DATASET_PATH = os.path.join(BASE_DIR, 'dataset', 'land_transactions.csv')
