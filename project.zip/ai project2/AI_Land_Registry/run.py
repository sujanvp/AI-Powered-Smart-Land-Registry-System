import os
from app import create_app
from dataset.generate_data import generate_synthetic_data
from ml.land_price_prediction import train_model as train_price_model
from ml.fraud_detection import train_model as train_fraud_model

app = create_app()

if __name__ == '__main__':
    # 1. Check for synthetic transaction dataset
    ds_path = app.config['DATASET_PATH']
    if not os.path.exists(ds_path):
        print("Generating synthetic dataset for ML model training...")
        generate_synthetic_data(ds_path, n_samples=1000)
        
    # 2. Check for ML models
    price_model_path = os.path.join(app.config['ML_MODEL_FOLDER'], 'price_model.pkl')
    fraud_model_path = os.path.join(app.config['ML_MODEL_FOLDER'], 'fraud_model.pkl')
    
    if not os.path.exists(price_model_path):
        print("Training land valuation prediction model...")
        train_price_model(ds_path, price_model_path)
        
    if not os.path.exists(fraud_model_path):
        print("Training transaction fraud classification model...")
        train_fraud_model(ds_path, fraud_model_path)
        
    print("\n--- Starting Flask Development Server ---")
    app.run(debug=True, host='127.0.0.1', port=5000)
